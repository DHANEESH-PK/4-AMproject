# GST Proof Desk — HNX26PSI08

Open `dist/gst-proof-desk.html` in any browser. All data is built in; no server, no install.

| File | What it is |
|---|---|
| `engine.js` | Exact JS port of `pda_common.py` (BigInt money, so sums are exact like Decimal) + question analyzer, data detective, truth gate, bounds/ranking/reconcile logic, independent auditor, Python proof generator |
| `app.js` | UI: proof-trail animation, answer stamps, range charts, dashboard, trap tracker, data tab |
| `shell.html`, `body.html` | Styles and markup |
| `data/`, `data_dictionary.md`, `pda_common.py` | Your package, embedded by `build.py` |
| `test.js` | `node test.js` — the 11 judge questions vs your reference `solutions/` (needs the original package path) + runs every generated Python proof |
| `test2.js` | `node test2.js questions.txt` — any questions vs Python proof and the hidden ground truth |
| `build.py` | `python build.py` → `dist/gst-proof-desk.html` |
