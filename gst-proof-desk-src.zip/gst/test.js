const fs = require("fs"), cp = require("child_process"), path = require("path");
const G = require("./engine.js");
G.PDA_COMMON = fs.readFileSync("pda_common.py", "utf8");
const T = {}; for (const f of fs.readdirSync("data")) { const t = G.parseCSV(fs.readFileSync("data/" + f, "utf8")); T[G.detectRole(Object.keys(t[0]))] = t; }
const d = G.load(T);
const REF = "/home/claude/pda_in/x/pda/solutions";
const QS = { q01: "Total gross collection recorded by source_system=gst_portal in FY2026-27 Q1, INR crore.",
  q02: "Total gross collection, all sources, FY2026-27 Q1, INR crore.",
  q03: "Top-3 states by NET collection in FY2025-26 Q4 (Jan-Mar 2026); refunds booked to month of original collection.",
  q04: "Gross collection by zone, FY2026-27 Q1, INR crore (zone from states.csv).",
  q05: "Which state figures in monthly_summary.csv for 2026-03 contradict collections.csv (system of record)?",
  q06: "Total gross collection in April 2026, INR crore.", q07: "USD value of total IGST collected in FY2026-27 Q1.",
  q08: "Total gross collection in July 2026 (INR crore).", q09: "Which state had the highest per-capita collection?",
  q10: "Year-on-year growth of FY2026-27 Q1 over FY2025-26 Q1.", q11: "Gross collection for FY2026-27 Q5." };
let fails = 0;
const ok = (c, m) => { if (!c) fails++; return c ? "✓" : "✗ " + m; };
for (const [id, q] of Object.entries(QS)) {
  const ref = JSON.parse(cp.execFileSync("python3", [path.join(REF, id + ".py")]).toString());
  const o = G.ask(q, d);
  let cmp;
  if (["q01", "q02", "q06", "q07"].includes(id)) cmp = ok(JSON.stringify(o.answer) === JSON.stringify(ref.answer) && o.status === ref.status, `${JSON.stringify(o.answer)} vs ${JSON.stringify(ref.answer)} ${o.status}/${ref.status}`);
  else if (id === "q03") cmp = ok(o.status === ref.status && JSON.stringify(Object.keys(o.answer.ranges).sort()) === JSON.stringify(Object.keys(ref.answer.ranges_inr_crore).sort()) && Object.entries(ref.answer.ranges_inr_crore).every(([s, r]) => JSON.stringify(o.answer.ranges[s]) === JSON.stringify(r)) && JSON.stringify(o.answer.top3_by_midpoint) === JSON.stringify(ref.answer.top3_by_midpoint), JSON.stringify(o.answer).slice(0, 300));
  else if (id === "q04") cmp = ok(Object.entries(ref.answer).every(([z, r]) => JSON.stringify(o.answer[z]) === JSON.stringify(r)) && o.contradictoryStates.some(c => c.state === "KA") && JSON.stringify([G.cr(o.unallocated.lo), G.cr(o.unallocated.hi)]) === JSON.stringify(ref.unallocated_state_codes_range_inr_crore), JSON.stringify(o.answer) + JSON.stringify(ref.answer));
  else if (id === "q05") cmp = ok(JSON.stringify(o.answer.confirmed_mismatch.map(x => [x.state, x.summary, x.computed_range])) === JSON.stringify(ref.answer.confirmed_mismatch.map(x => [x.state, x.summary, x.computed_range])) && o.answer.not_contradicted.length === ref.answer.not_contradicted.length, JSON.stringify(o.answer.confirmed_mismatch.map(x=>x.state)));
  else if (id === "q08") cmp = ok(o.status === "CANNOT_DETERMINE" && o.lowerBoundInrOnly === ref.lower_bound_inr_rows_only_inr_crore, `${o.status} ${o.lowerBoundInrOnly} vs ${ref.lower_bound_inr_rows_only_inr_crore}`);
  else cmp = ok(o.status === ref.status, `${o.status} vs ${ref.status}: ${o.reason}`);
  // python proof
  let py = "";
  if (o.python) {
    fs.mkdirSync("/tmp/gp", { recursive: true }); fs.writeFileSync("/tmp/gp/proof.py", o.python);
    const r = JSON.parse(cp.execFileSync("python3", ["/tmp/gp/proof.py", path.resolve("data")], { cwd: "/tmp" }).toString());
    const flat = x => JSON.stringify(x);
    let match;
    if (o.spec.shape === "top") match = Object.entries(o.answer.ranges).every(([k, v]) => flat(r.answer.ranges[k]) === flat(v)) && flat(r.answer.top_by_midpoint) === flat(Object.values(o.answer)[0]);
    else if (o.spec.shape === "breakdown") match = o.items.every(i => flat(r.answer[i.key]) === flat(i.range));
    else if (o.spec.shape === "reconcile") match = flat(r.answer.confirmed_mismatch.map(x => x.state)) === flat(o.answer.confirmed_mismatch.map(x => x.state));
    else match = flat(Array.isArray(r.answer) ? r.answer.flat() : [r.answer, r.answer]) === flat(o.check);
    py = ok(match, "python " + flat(r.answer).slice(0, 200) + " vs " + flat(o.check));
  }
  console.log(id, o.status.padEnd(25), "ref", cmp, " python", py || "—", " audit", o.audit ? (o.audit.agree ? "✓" : "✗") : "—");
}
console.log(fails ? `\n${fails} FAIL(S)` : "\nALL 11 MATCH THE REFERENCE SOLUTIONS");
