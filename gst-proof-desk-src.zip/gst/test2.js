const fs = require("fs"), cp = require("child_process"), path = require("path");
const G = require("./engine.js"); G.PDA_COMMON = fs.readFileSync("pda_common.py", "utf8");
const T = {}; for (const f of fs.readdirSync("data")) { const t = G.parseCSV(fs.readFileSync("data/" + f, "utf8")); T[G.detectRole(Object.keys(t[0]))] = t; }
const d = G.load(T);
const truth = G.parseCSV(fs.readFileSync("/home/claude/pda_in/x/pda/_hidden/truth_records.csv", "utf8"));
const FX = Object.fromEntries(T.fx_rates.map(r => [r.month, +r.rate]));
const zone = { MH: "West", GJ: "West", KA: "South", TN: "South", KL: "South", DL: "North", UP: "North", RJ: "North", WB: "East", OD: "East" };
function tsum(spec) {
  const W = new Set(spec.months || d.allMonths); let s = 0;
  for (const r of truth) { if (r.inr === "" || !W.has(r.date.slice(0, 7))) continue;
    if (spec.states.length && !spec.states.includes(r.state)) continue; if (spec.tax && r.tax !== spec.tax) continue; if (spec.source && r.source !== spec.source) continue;
    if (spec.zone && zone[r.state] !== spec.zone) continue;
    let v = spec.measure === "net" ? +r.inr - +r.refund_inr : spec.measure === "refund" ? +r.refund_inr : +r.inr;
    s += spec.unit === "usd" ? v / FX[r.date.slice(0, 7)] : v; }
  return spec.unit === "usd" ? s : s / 1e7;
}
const Q = fs.readFileSync(process.argv[2] || "/dev/stdin", "utf8").split("\n").filter(Boolean);
let bad = 0;
for (const q of Q) {
  const o = G.ask(q, d); let note = "";
  if (o.python) {
    fs.writeFileSync("/tmp/gp/proof.py", o.python);
    let r; try { r = JSON.parse(cp.execFileSync("python3", ["/tmp/gp/proof.py", path.resolve("data")], { cwd: "/tmp", stdio: ["ignore", "pipe", "pipe"] }).toString()); } catch (e) { r = { err: e.stderr?.toString().slice(-300) }; }
    const flat = JSON.stringify; let m;
    if (r.err) m = false;
    else if (o.spec.shape === "top") m = Object.entries(o.answer.ranges).every(([k, v]) => flat(r.answer.ranges[k]) === flat(v));
    else if (o.spec.shape === "breakdown") m = o.items.every(i => i.incomplete || flat(r.answer[i.key]) === flat(i.range));
    else if (o.spec.shape === "reconcile") m = flat(r.answer.confirmed_mismatch.map(x => x.state)) === flat(o.answer.confirmed_mismatch.map(x => x.state));
    else if (o.spec.shape === "count") m = flat(r.answer) === flat(o.check.map(Number));
    else if (o.spec.shape === "compare") m = flat(r.answer.flat()) === flat(o.check);
    else m = flat(Array.isArray(r.answer) ? r.answer.flat() : [r.answer, r.answer]) === flat(o.check);
    note += m ? " py✓" : " PY✗ " + flat(r).slice(0, 160);
    if (!m) bad++;
  }
  if (o.lo !== undefined && ["total", "threshold"].includes(o.spec.shape)) {
    const t = tsum(o.spec), lo = +o.check[0], hi = +o.check[1], inside = t >= lo - 0.006 && t <= hi + 0.006;
    note += inside ? ` truth ${t.toFixed(2)} ∈ range ✓` : ` TRUTH ${t.toFixed(2)} OUTSIDE ✗`; if (!inside) bad++;
  }
  if (o.audit && o.audit.agree === false) { note += " AUDIT✗"; bad++; }
  const ans = o.status.startsWith("ANSWERED") || o.status === "CANNOT_DETERMINE_RANKING" ? (o.headline || "") + " " + (typeof o.answer === "string" || Array.isArray(o.answer) ? JSON.stringify(o.answer) : "") : (o.reason || "").slice(0, 110);
  console.log(`${o.status.padEnd(24)} ${q.padEnd(62).slice(0, 62)} → ${ans.slice(0, 120)}${note}`);
}
console.log(bad ? `\n${bad} PROBLEM(S)` : "\nall extra questions consistent (python, auditor, hidden truth)");
