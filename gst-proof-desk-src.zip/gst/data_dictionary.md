# Data Dictionary — Synthetic India GST Ledger (2026)

The "documents" half of the problem statement. The agent must READ this, not guess.

> **Provenance:** the schema is modelled on Economy-sector datasets published on data.gov.in
> (state-wise GST collection, GST refunds, RBI INR/USD reference rates). The values are
> **synthetic** (seeded generator `generate_data.py`) so that every trap has a known ground truth.
> They are not official statistics and must not be quoted as such.

## Business rules
- Reporting currency is **INR**; headline figures are in **INR crore** (1 crore = 10,000,000).
- USD amounts are converted at the month-average rate in `fx_rates.csv` (month of the collection date).
- The **fiscal year starts 1 April**. FY Q1 = Apr–Jun, FY Q2 = Jul–Sep, FY Q3 = Oct–Dec, FY Q4 = Jan–Mar.
  "FY2026-27 Q1" = Apr–Jun 2026; "FY2025-26 Q4" = Jan–Mar 2026. There are exactly four quarters.
- Gross collection = sum of `amount` over `collections.csv`. Net collection = gross minus refunds
  (refunds are booked to the month of the **original collection**, not the refund date).
- `monthly_summary.csv` is a finance export prepared **manually**. `collections.csv` is the **system of record**.
- Tax types: CGST, SGST, IGST, CESS.

## collections.csv
| column | meaning |
|---|---|
| record_id | unique record key (re-exports can repeat a row) |
| state_code | FK to states.csv (2-letter code) |
| tax_type | CGST / SGST / IGST / CESS |
| collection_date | text date — format depends on `source_system` |
| source_system | `gst_portal` = DD/MM/YYYY, `state_treasury` = MM/DD/YYYY, `legacy` = **format not documented** |
| amount | text; may carry `₹`, `Rs.`, `$`; `gst_portal` uses Indian digit grouping (`1,23,45,678.90`), `state_treasury` uses `.` for thousands and `,` for decimals (`12.345.678,90`), `legacy` has no thousands separator; may be blank |
| currency | ISO code (`INR` / `USD`); may be blank when the amount text already carries a symbol |

## states.csv
state_code, state_name, zone (North / South / East / West). One zone per state is expected.

## refunds.csv
refund_id, record_id (FK to collections.csv), refund_date (ISO), amount (plain number), currency (same as the original record).

## fx_rates.csv
month (YYYY-MM), from_ccy, to_ccy, rate. Direction: 1 USD = `rate` INR. Coverage: 2026-01 to 2026-06.

## monthly_summary.csv
month (YYYY-MM), state_code, net_revenue_inr_crore. Manual finance export for 2026-01 to 2026-06.

## Row counts
collections.csv 412 rows · refunds.csv 57 · states.csv 11 · fx_rates.csv 6 · monthly_summary.csv 60.
Collections span 2026-01 to 2026-07.
