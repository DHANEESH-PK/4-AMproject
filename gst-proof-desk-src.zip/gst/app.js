/* GST Proof Desk — UI */
(function () {
  "use strict";
  const $ = s => document.querySelector(s);
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  G.PDA_COMMON = PDA_COMMON_SRC;
  let T = {}, d = null;
  const ROLE_FILE = { collections: "collections.csv", refunds: "refunds.csv", states: "states.csv", fx_rates: "fx_rates.csv", monthly_summary: "monthly_summary.csv" };
  function loadBuiltIn() { T = {}; for (const [name, text] of Object.entries(DATA_FILES)) { const rows = G.parseCSV(text); T[G.detectRole(Object.keys(rows[0]))] = rows; } T._src = Object.fromEntries(Object.entries(DATA_FILES).map(([n, t]) => [G.detectRole(Object.keys(G.parseCSV(t)[0])), { name: n, text: t, builtIn: true }])); d = G.load(T); window.GPD_DATA = d; }

  /* ------------------------------------------------------------ formatting */
  const fmtNum = (s, unit) => { if (s === null || s === undefined) return "—"; const n = Number(s); return n.toLocaleString(unit === "USD" ? "en-US" : "en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  const U = unit => unit === "USD" ? "USD" : unit === "records" ? "records" : "₹ crore";
  const C = (x, unit) => fmtNum(unit === "USD" ? G.q2(x) : G.cr(x), unit);   // BigInt -> display
  function countUp(el) {
    const target = Number(el.dataset.to), unit = el.dataset.unit, dec = unit === "records" ? 0 : 2;
    const show = v => (el.textContent = unit === "records" ? Math.round(v).toLocaleString("en-IN") : v.toLocaleString(unit === "USD" ? "en-US" : "en-IN", { minimumFractionDigits: dec, maximumFractionDigits: dec }));
    if (reduce || !Number.isFinite(target)) return show(target);
    const t0 = performance.now(), dur = 900;
    const step = t => { const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3); show(target * e); if (p < 1) requestAnimationFrame(step); else show(target); };
    requestAnimationFrame(step);
  }
  const cu = (s, unit) => `<span class="cu" data-to="${esc(s)}" data-unit="${esc(unit)}">${fmtNum(s, unit)}</span>`;

  /* ----------------------------------------------------------------- tabs */
  function tab(name) {
    for (const t of ["ask", "glance", "traps", "data"]) { $(`#t-${t}`).setAttribute("aria-selected", String(t === name)); $(`#v-${t}`).hidden = t !== name; }
    if (name === "glance") renderGlance(); if (name === "traps") renderTraps(); if (name === "data") renderData();
    try { localStorage.setItem("gpd-tab", name); } catch (e) { /* storage blocked */ }
  }

  /* ------------------------------------------------------------ questions */
  const ELEVEN = [
    ["Q01", "Total gross collection recorded by source_system=gst_portal in FY2026-27 Q1, INR crore."],
    ["Q02", "Total gross collection, all sources, FY2026-27 Q1, INR crore."],
    ["Q03", "Top-3 states by NET collection in FY2025-26 Q4 (Jan-Mar 2026); refunds booked to month of original collection."],
    ["Q04", "Gross collection by zone, FY2026-27 Q1, INR crore (zone from states.csv)."],
    ["Q05", "Which state figures in monthly_summary.csv for 2026-03 contradict collections.csv (system of record)?"],
    ["Q06", "Total gross collection in April 2026, INR crore."],
    ["Q07", "USD value of total IGST collected in FY2026-27 Q1."],
    ["Q08", "Total gross collection in July 2026 (INR crore)."],
    ["Q09", "Which state had the highest per-capita collection?"],
    ["Q10", "Year-on-year growth of FY2026-27 Q1 over FY2025-26 Q1."],
    ["Q11", "Gross collection for FY2026-27 Q5."]];
  const SHORT = { Q01: "Portal gross, FY26-27 Q1", Q02: "All sources, FY26-27 Q1", Q03: "Top-3 states by net", Q04: "By zone", Q05: "Summary vs ledger", Q06: "April gross", Q07: "IGST in USD", Q08: "July gross", Q09: "Per-capita", Q10: "Year-on-year", Q11: "FY Q5" };
  const MORE = [
    ["ask", "Did we collect more in May 2026 than in April 2026?"], ["ask", "Net collection by month"], ["ask", "How much IGST did Karnataka collect in April 2026?"],
    ["ask", "Which zone had the highest gross collection in FY2026-27 Q1?"], ["ask", "Total refunds in January 2026"], ["ask", "Collection by tax type in FY2026-27 Q1"],
    ["trap", "What was collection last month?"], ["trap", "Gross collection in Q1"], ["trap", "Why did collections fall in April 2026?"], ["trap", "Gross collection in Goa in March 2026"]];
  function renderChips() {
    $("#eleven").innerHTML = ELEVEN.map(([id, q]) => `<button class="chip" type="button" data-q="${esc(q)}" title="${esc(q)}"><b>${id}</b><span>${esc(SHORT[id])}</span></button>`).join("");
    $("#more").innerHTML = MORE.map(([k, q]) => `<button class="chip ${k === "trap" ? "trap" : ""}" type="button" data-q="${esc(q)}"><b>${k === "trap" ? "trap" : "try"}</b><span>${esc(q)}</span></button>`).join("");
  }
  // typewriter placeholder
  (function typewriter() {
    if (reduce) return;
    const ex = ["Net collection by state in April 2026", "Did refunds exceed 50 crore in March 2026?", "Top 3 states by gross collection in June 2026", "CESS collection in USD in May 2026"];
    let i = 0, j = 0, back = false; const inp = $("#q");
    setInterval(() => {
      if (document.activeElement === inp || inp.value) return;
      const s = ex[i]; j += back ? -2 : 1;
      if (j > s.length + 18) back = true; if (back && j <= 0) { back = false; i = (i + 1) % ex.length; j = 0; }
      inp.placeholder = s.slice(0, Math.max(0, Math.min(j, s.length))) + (j <= s.length ? "▍" : "");
    }, 70);
  })();

  /* ---------------------------------------------------------- the trail */
  const STATIONS = ["Question analyzer", "Data detective", "Truth gate", "Code generator", "Code execution", "Auditor", "Final verifier"];
  function stationStates(o) {
    const answered = o.status && o.status.startsWith("ANSWERED") || o.status === "CANNOT_DETERMINE_RANKING";
    const analyzerStop = o.spec && o.spec.status && o.spec.status !== "OK";
    const audFail = o.audit && o.audit.agree === false;
    const st = [], gateCls = o.status === "ANSWERED" ? "pass" : answered ? "warn" : "stop";
    st.push([analyzerStop ? "warn" : "pass", analyzerStop ? "flagged the question" : (o.trail.analyzer || "")]);
    st.push([analyzerStop ? "skip" : (o.warnings && o.warnings.length ? "warn" : "pass"), analyzerStop ? "not needed" : (o.trail.detective || "")]);
    st.push([audFail ? "stop" : gateCls, { ANSWERED: "exact answer allowed", ANSWERED_RANGE: "only a range is provable", CANNOT_DETERMINE_RANKING: "ranking not provable", CANNOT_DETERMINE: "refused, with reason", INVALID_QUESTION: "question is invalid" }[o.status] || o.status]);
    const ran = !!o.python;
    st.push([ran ? "pass" : "skip", ran ? "proof.py written" : "nothing to prove"]);
    st.push([ran ? "pass" : "skip", ran ? `ran in ${o.ms} ms` : "—"]);
    st.push([audFail ? "stop" : o.audit ? "pass" : "skip", o.trail.auditor || "—"]);
    st.push([ran ? "pass" : (answered ? "pass" : "skip"), o.trail.verifier || "—"]);
    return st;
  }
  function renderTrail(o) {
    const st = stationStates(o);
    $("#trail").innerHTML = `<section class="trail" aria-label="Proof trail"><header><h2>Proof trail</h2><span class="muted" style="font-size:13px">your pipeline, live for this question</span></header>
      <div class="stations"><div class="spark" id="spark"></div>${STATIONS.map((n, i) => `<div class="station" data-i="${i}" data-cls="${st[i][0]}"><div class="dot">${st[i][0] === "pass" ? "✓" : st[i][0] === "warn" ? "!" : st[i][0] === "stop" ? "✕" : "·"}</div><b>${esc(n)}</b><span>${esc(st[i][1])}</span></div>`).join("")}</div></section>`;
    const nodes = [...document.querySelectorAll(".station")], spark = $("#spark");
    return new Promise(res => {
      if (reduce) { nodes.forEach(n => n.classList.add("lit", n.dataset.cls)); return res(); }
      let i = 0;
      const tick = () => {
        if (i >= nodes.length) { spark.style.opacity = 0; return res(); }
        const n = nodes[i];
        spark.style.opacity = 1; spark.style.transition = "left .16s ease-out";
        spark.style.left = `calc(${(i + 0.5) / nodes.length * 100}% - 6px)`;
        n.classList.add("lit", n.dataset.cls);
        i++; const stopHere = n.dataset.cls === "stop" && i < nodes.length;
        if (stopHere) { nodes.slice(i).forEach(x => x.classList.add("skip")); spark.style.opacity = 0; return setTimeout(res, 200); }
        setTimeout(tick, 170);
      };
      tick();
    });
  }

  /* --------------------------------------------------------------- answer */
  let lastPython = "";
  async function ask(q) {
    q = q.trim(); if (!q) return; $("#q").value = q;
    const o = G.ask(q, d);
    $("#answer").innerHTML = "";
    await renderTrail(o);
    renderAnswer(o);
    document.querySelectorAll("#answer .cu").forEach(countUp);
  }
  const STAMP = { ANSWERED: ["exact", "Proven", "exact answer"], ANSWERED_RANGE: ["range", "Proven range", "can’t be one number"], CANNOT_DETERMINE_RANKING: ["range", "Ranking unproven", "ranges overlap"], CANNOT_DETERMINE: ["no", "Can’t determine", "won’t guess"], INVALID_QUESTION: ["inv", "Invalid question", "no such thing"] };
  function hero(o) {
    const unit = o.unit === "USD" ? "USD" : o.unit === "records" ? "records" : "INR crore";
    if (o.verdict) return `<div class="bignum">${esc(o.verdict)}</div>`;
    if (typeof o.answer === "string") return `<div class="bignum">${cu(o.answer, unit)}<small>${U(unit)}</small></div>`;
    if (Array.isArray(o.answer) && typeof o.answer[0] === "string") return `<div class="bignum">${cu(o.answer[0], unit)}<span class="dash">–</span>${cu(o.answer[1], unit)}<small>${U(unit)}</small></div>`;
    return "";
  }
  function renderAnswer(o) {
    const [cls, word, sub] = STAMP[o.status] || ["inv", o.status, ""];
    const refused = o.status === "CANNOT_DETERMINE" || o.status === "INVALID_QUESTION";
    let h = `<article class="answer"><div class="verdict"><div><div class="asked">You asked: “${esc(o.spec?.question || $("#q").value)}”</div>
      <h2>${esc(refused ? (o.status === "INVALID_QUESTION" ? "That question has no valid answer." : "I can’t determine this from the data.") : o.headline || "")}</h2>${refused ? "" : hero(o)}</div>
      <div class="stamp ${cls}">${esc(word)}<small>${esc(sub)}</small></div></div>`;
    if (refused) {
      h += `<div class="sec"><h3>Why</h3><div class="why"><p>${esc(o.reason)}</p>${o.fix ? `<div class="fix"><b>What would make it answerable:</b> ${esc(o.fix)}</div>` : ""}
        ${o.lowerBoundInrOnly ? `<div class="note"><i>i</i><span>For reference only: INR-only records add up to at least ${fmtNum(o.lowerBoundInrOnly)} ₹ crore. That is a lower bound, not an answer.</span></div>` : ""}</div></div>`;
      h += `<div class="sec"><h3>Why refuse instead of estimate</h3><p style="margin:0;color:var(--ink-2)">A confident wrong number scores worse than an honest “can’t determine”. The desk only answers what the data can prove.</p></div>`;
      $("#answer").innerHTML = h + "</article>"; return;
    }
    if (o.reason) h += `<div class="sec"><h3>Why it’s not a plain yes or no</h3><p style="margin:0">${esc(o.reason)}</p></div>`;
    h += `<div class="sec"><h3>Picture</h3>${chartFor(o)}</div>`;
    h += `<div class="sec"><h3>Proof</h3><ol class="steps">${o.steps.map((s, i) => `<li style="animation-delay:${i * 60}ms"><span>${esc(s)}</span></li>`).join("")}</ol></div>`;
    if (o.warnings.length || o.spec.notes.length) h += `<div class="sec"><h3>Traps found on the way</h3><div class="notes">${[...o.spec.notes.map(n => ["", n]), ...o.warnings.map(w => ["", w])].map(([c, t]) => `<div class="note ${c}"><i>!</i><span>${esc(t)}</span></div>`).join("")}</div></div>`;
    // verification
    const checks = [];
    if (o.audit && o.audit.lo !== undefined) checks.push([o.audit.agree, "Independent recount", `A second implementation re-read the raw CSV text with its own parsers: ${o.audit.lo === o.audit.hi ? fmtNum(o.audit.lo, o.unit) : fmtNum(o.audit.lo, o.unit) + " – " + fmtNum(o.audit.hi, o.unit)}. ${o.audit.agree ? "Matches to the paisa." : "Does NOT match."}`]);
    else if (o.audit) checks.push([true, "Group totals re-derived", "Each group was recomputed with the same exact bounds, and the Python proof below recomputes every one."]);
    checks.push([true, "Exact arithmetic", "Amounts are summed as exact decimals (like Python’s Decimal) and rounded half-up only at the end."]);
    checks.push([true, "Same rules as the reference", "Uses pda_common.py logic: documented date formats, exact-duplicate drop, conflicting re-exports in the upper bound only, refunds in the month of the original collection."]);
    checks.push([true, "Rerunnable proof", "The script below embeds pda_common.py verbatim and prints the same figures. It needs only the Python standard library."]);
    h += `<div class="sec"><h3>Verification</h3><div class="checks">${checks.map(([ok, t, s]) => `<div class="check ${ok ? "" : "bad"}"><b>${esc(t)}</b><span>${esc(s)}</span></div>`).join("")}</div></div>`;
    if (o.rows) h += evidence(o);
    if (o.python) {
      lastPython = o.python;
      h += `<div class="sec"><details><summary>Proof script — rerun this yourself</summary>
        <div class="codebar"><span>Save as <code>proof.py</code> next to a <code>data/</code> folder holding the five CSVs (copy them from “The data” tab), then run <code>python proof.py</code>.</span><button class="btn" type="button" data-copy="py">Copy script</button></div>
        <pre class="code" id="pycode">${highlight(o.python)}</pre></details></div>`;
    }
    $("#answer").innerHTML = h + "</article>";
  }
  function evidence(o) {
    const r = o.rows, rows = [...r.certain.map(x => [x, "certain"]), ...r.ambiguous.map(x => [x, "ambiguous date"])];
    const tr = ([x, role]) => `<tr><td>${esc(x.id)}</td><td>${esc(x.state)}</td><td>${esc(x.tax)}</td><td>${esc(x.source)}</td><td>${esc(x.raw.collection_date)}</td><td class="r">${esc(x.raw.amount)}</td><td>${esc(x.ccy)}</td><td>${esc(x.months.join(" or "))}</td><td><span class="tag ${role === "certain" ? "ok" : "amb"}">${role}</span></td></tr>`;
    return `<div class="sec"><details><summary>Evidence: ${r.certain.length} certain record(s), ${r.ambiguous.length} ambiguous, ${r.conflict.length} conflicting ID(s)</summary>
      <div class="tbl"><table><thead><tr><th>record_id</th><th>state</th><th>tax</th><th>source</th><th>date as written</th><th class="r">amount as written</th><th>ccy</th><th>possible month</th><th>role</th></tr></thead><tbody>${rows.slice(0, 400).map(tr).join("")}
      ${r.conflict.map(id => `<tr><td>${esc(id)}</td><td colspan="7">${esc(d.conflicts[id].map(v => `${v.raw.amount} (${v.raw.collection_date})`).join(" vs "))}</td><td><span class="tag cf">conflict → upper bound</span></td></tr>`).join("")}</tbody></table></div></details></div>`;
  }
  function highlight(code) {
    const re = /(#[^\n]*)|("""[\s\S]*?"""|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|\b(import|from|def|return|if|elif|else|for|in|not|and|or|is|None|True|False|lambda|raise|try|except|continue)\b|\b(\d+(?:\.\d+)?)\b/g;
    let out = "", last = 0, m;
    while ((m = re.exec(code))) { out += esc(code.slice(last, m.index)); out += `<span class="tok-${m[1] ? "c" : m[2] ? "s" : m[3] ? "k" : "n"}">${esc(m[0])}</span>`; last = re.lastIndex; }
    return out + esc(code.slice(last));
  }

  /* ---------------------------------------------------------------- charts */
  const vw = () => Math.max(320, document.documentElement.clientWidth);
  const slot = k => { const page = Math.min(1160, vw() - 32); if (k === "half") return vw() > 900 ? (page - 14) / 2 - 42 : page - 42; if (k === "card") return page - (vw() > 640 ? 54 : 42); return page - 42; };
  let pid = 0;
  const hatch = (id, color) => `<defs><pattern id="${id}" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="8" height="8" fill="${color}" fill-opacity=".18"/><line x1="0" y1="0" x2="0" y2="8" stroke="${color}" stroke-width="3"/></pattern></defs>`;
  function ticks(max, n = 4) {
    if (max <= 0) return [0, 1]; const step0 = max / n, mag = Math.pow(10, Math.floor(Math.log10(step0)));
    const step = [1, 2, 2.5, 5, 10].map(s => s * mag).find(s => max / s <= n) || 10 * mag; const out = []; for (let v = 0; v <= max + step * 0.999; v += step) out.push(v); return out;
  }
  const short = v => { const a = Math.abs(v); return a >= 1e9 ? (v / 1e9).toFixed(1) + "B" : a >= 1e6 ? (v / 1e6).toFixed(a >= 1e7 ? 0 : 1) + "M" : a >= 1e3 ? (v / 1e3).toFixed(a >= 1e4 ? 0 : 1) + "k" : String(Math.round(v)); };
  const toN = (x, unit) => Number(unit === "USD" ? G.q2(x) : G.cr(x));
  function legendRange(color, name) { return `<div class="legend"><span><i style="background:${color}"></i>${esc(name)}: certain</span><span><i style="background:repeating-linear-gradient(45deg,${color} 0 3px,transparent 3px 6px);border:1px solid ${color}"></i>might add (ambiguous dates / conflicting re-exports)</span></div>`; }
  function rangeRows(items, unit, opts = {}) {
    const W = Math.round(opts.W || slot("card")), rowH = 34, lw = Math.min(W < 480 ? 104 : 190, 16 + Math.max(...items.map(i => Math.min(26, i.label.length))) * 7.2), right = W < 480 ? 92 : 150;
    const H = items.length * rowH + 24, max = Math.max(...items.map(i => toN(i.hi, unit)), opts.mark ? toN(opts.mark, unit) : 0, 0.01);
    const t = ticks(max), x = v => lw + v / t[t.length - 1] * (W - lw - right), id = "h" + (++pid), color = opts.color || "var(--gross)";
    let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(opts.title || "ranges")}">${hatch(id, color)}${t.map(v => `<line class="gridl" x1="${x(v)}" x2="${x(v)}" y1="0" y2="${H - 20}"/><text class="lbl" x="${x(v)}" y="${H - 5}" text-anchor="middle">${short(v)}</text>`).join("")}`;
    if (opts.gap !== undefined) { const gx = x(toN(opts.gap, unit)); s += `<line x1="${gx}" x2="${gx}" y1="0" y2="${H - 20}" stroke="var(--ink)" stroke-dasharray="4 3"/><text class="lbl" x="${gx + 4}" y="${H - 24}">best of the rest</text>`; }
    items.forEach((it, i) => {
      const y = i * rowH + 6, h = rowH - 14, lo = toN(it.lo, unit), hi = toN(it.hi, unit), hl = opts.highlight?.includes(it.key);
      const fx2 = v => fmtNum(unit === "USD" ? G.q2(v) : G.cr(v), unit);
      const tip = `${it.label}: ${it.incomplete ? "can’t determine (no FX for some USD rows)" : it.lo === it.hi ? fx2(it.lo) : fx2(it.lo) + " – " + fx2(it.hi)} ${U(unit)}`;
      s += `<text class="rowlbl" x="${lw - 10}" y="${y + h / 2 + 4}" text-anchor="end" ${hl ? 'style="font-weight:700;fill:var(--ink)"' : ""}>${esc(it.label.length > 26 ? it.label.slice(0, 25) + "…" : it.label)}</text>`;
      if (hl) s += `<rect x="${lw - 4}" y="${y - 4}" width="${Math.max(10, x(hi) - lw + 8)}" height="${h + 8}" rx="8" fill="none" stroke="var(--marigold)" stroke-width="2" class="grow" style="animation-delay:${i * 50}ms"/>`;
      s += `<g data-tip="${esc(tip)}"><rect class="grow" style="animation-delay:${i * 50}ms" x="${lw}" y="${y}" width="${Math.max(0, x(lo) - lw)}" height="${h}" rx="5" fill="${color}"/>`;
      if (hi > lo) s += `<rect class="grow" style="animation-delay:${i * 50 + 250}ms" x="${x(lo)}" y="${y}" width="${Math.max(2, x(hi) - x(lo))}" height="${h}" rx="5" fill="url(#${id})" stroke="${color}" stroke-width="1"/>`;
      s += `</g><text class="val" x="${x(Math.max(hi, lo)) + 8}" y="${y + h / 2 + 4}">${it.incomplete ? "no FX ?" : lo === hi ? short(lo) : short(lo) + "–" + short(hi)}</text>`;
    });
    if (opts.mark) { const mx = x(toN(opts.mark, unit)); s += `<line x1="${mx}" x2="${mx}" y1="0" y2="${H - 20}" stroke="var(--refund)" stroke-width="2"/><text class="lbl" x="${mx + 4}" y="10" style="fill:var(--refund)">threshold</text>`; }
    return `<div class="viz">${s}</svg></div>`;
  }
  function monthCols(items, unit, color, W) {
    W = Math.round(W || slot("wide")); const H = 250, l = 46, b = 28, top = 18, r = 8, id = "h" + (++pid);
    const max = Math.max(...items.map(i => toN(i.hi, unit)), 0.01), t = ticks(max), y = v => top + (1 - v / t[t.length - 1]) * (H - top - b);
    const band = (W - l - r) / items.length, bw = Math.min(54, band * .56);
    let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="by month">${hatch(id, color)}${t.map(v => `<line class="gridl" x1="${l}" x2="${W - r}" y1="${y(v)}" y2="${y(v)}"/><text class="lbl" x="${l - 6}" y="${y(v) + 4}" text-anchor="end">${short(v)}</text>`).join("")}`;
    items.forEach((it, i) => {
      const cx = l + band * i + band / 2, lo = toN(it.lo, unit), hi = toN(it.hi, unit);
      const tip = `${it.label}: ${it.incomplete ? "cannot determine — " + it.info.unconvertible + " USD row(s) have no FX rate; INR rows alone ≥ " : ""}${unit === "USD" ? G.q2(it.lo) : G.cr(it.lo)}${hi > lo ? " – " + (unit === "USD" ? G.q2(it.hi) : G.cr(it.hi)) : ""} ${U(unit)}`;
      s += `<g data-tip="${esc(tip)}"><rect class="growy" style="animation-delay:${i * 70}ms" x="${cx - bw / 2}" y="${y(lo)}" width="${bw}" height="${Math.max(0, y(0) - y(lo))}" rx="6" fill="${color}" ${it.incomplete ? 'fill-opacity=".35"' : ""}/>`;
      if (hi > lo) s += `<rect class="growy" style="animation-delay:${i * 70 + 300}ms" x="${cx - bw / 2}" y="${y(hi)}" width="${bw}" height="${Math.max(2, y(lo) - y(hi))}" rx="6" fill="url(#${id})" stroke="${color}"/>`;
      s += `</g>`;
      if (it.incomplete) s += `<text x="${cx}" y="${y(lo) - 8}" text-anchor="middle" style="fill:var(--refund);font:700 16px var(--mono)">?</text>`;
      s += `<text class="lbl" x="${cx}" y="${H - 8}" text-anchor="middle">${esc(it.label.split(" ")[0])}</text>`;
    });
    return `<div class="viz">${s}</svg></div>`;
  }
  function dumbbell(rows) {
    const W = Math.round(slot("card")), rowH = 30, lw = 54, right = 120, H = rows.length * rowH + 24;
    const max = Math.max(...rows.map(r => Math.max(Number(r.computed_range[1]), Number(r.summary)))), t = ticks(max), x = v => lw + v / t[t.length - 1] * (W - lw - right);
    let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="summary vs ledger">${t.map(v => `<line class="gridl" x1="${x(v)}" x2="${x(v)}" y1="0" y2="${H - 20}"/><text class="lbl" x="${x(v)}" y="${H - 5}" text-anchor="middle">${short(v)}</text>`).join("")}`;
    rows.forEach((r, i) => {
      const y = i * rowH + 14, a = Number(r.computed_range[0]), b = Number(r.computed_range[1]), v = Number(r.summary), bad = v < a - 0.01 || v > b + 0.01;
      s += `<text class="rowlbl" x="${lw - 10}" y="${y + 4}" text-anchor="end">${esc(r.state)}</text>`;
      s += `<g data-tip="${esc(`${r.state}: ledger ${r.computed_range[0]}–${r.computed_range[1]} · summary ${r.summary} → ${bad ? "MISMATCH" : "not contradicted"}`)}"><rect class="grow" x="${x(a)}" y="${y - 6}" width="${Math.max(6, x(b) - x(a))}" height="12" rx="6" fill="var(--net)" fill-opacity=".85"/>
        <circle cx="${x(v)}" cy="${y}" r="6.5" fill="${bad ? "var(--refund)" : "var(--marigold)"}" stroke="var(--surface)" stroke-width="2" class="${bad ? "pulse" : ""}"/></g>`;
      s += `<text class="val" x="${Math.max(x(b), x(v)) + 12}" y="${y + 4}" style="${bad ? "fill:var(--refund);font-weight:700" : ""}">${bad ? "mismatch" : "ok"}</text>`;
    });
    return `<div class="legend"><span><i style="background:var(--net)"></i>range the ledger allows</span><span><i style="background:var(--marigold);border-radius:50%"></i>summary figure</span><span><i style="background:var(--refund);border-radius:50%"></i>summary outside range</span></div><div class="viz">${s}</svg></div>`;
  }
  function chartFor(o) {
    const unit = o.unit === "USD" ? "USD" : "INR crore", c = o.chart, color = o.spec.measure === "net" ? "var(--net)" : o.spec.measure === "refund" ? "var(--refund)" : "var(--gross)";
    if (!c) return `<p class="muted" style="margin:0">A count — no chart needed.</p>`;
    if (c.type === "reconcile") return dumbbell(c.rows);
    if (c.type === "months") return legendRange(color, o.spec.measure) + monthCols(c.items, unit, color, slot("card"));
    if (c.type === "band") return legendRange(color, "total") + rangeRows([{ key: "t", label: o.spec.months ? G.label(o.spec.months) : "All data", lo: c.lo, hi: c.hi }], unit, { color, mark: c.mark })
      + `<p class="muted" style="font-size:13.5px;margin:6px 0 0">${c.lo === c.hi ? "Every record behind this total is certain, so the bar is solid." : `The true value is somewhere in the striped part: ${c.info.ambiguous} record(s) can’t be placed with certainty${c.info.conflicting_record_ids_in_window ? ` and ${c.info.conflicting_record_ids_in_window} ID(s) were exported twice with different amounts` : ""}.`}</p>`;
    if (c.type === "ranges") {
      let gap; if (o.spec.shape === "top" && o.spec.topDir === "desc") { const rest = c.items.filter(i => !c.highlight.includes(i.key)); if (rest.length) gap = rest.reduce((a, i) => (i.hi > a ? i.hi : a), 0n); }
      return legendRange(color, o.spec.measure) + rangeRows(c.items, unit, { color, highlight: c.highlight, gap }) + (o.spec.shape === "top" ? `<p class="muted" style="font-size:13.5px;margin:6px 0 0">${c.determinate ? "The marigold-ringed bars start to the right of the dashed line, so no possible reading changes the ranking." : "At least one marigold-ringed bar starts left of the dashed line, so the ranking can flip. The desk won’t claim it."}</p>` : "");
    }
    return "";
  }

  /* ----------------------------------------------------------------- glance */
  const G_STATE = { measure: "gross", period: "FY2026-27 Q1" };
  const periodMap = () => { const m = Object.fromEntries([["FY2025-26 Q4", G.fyQuarterMonths(2025, 4)], ["FY2026-27 Q1", G.fyQuarterMonths(2026, 1)]]); d.certainMonths.forEach(k => (m[G.monthLabel(k)] = [k])); return m; };
  function breakdown(months, measure, groupBy) {
    return G.run({ question: "", measure, unit: "crore", months, periods: [months], states: [], zone: null, tax: null, source: null, shape: "breakdown", groupBy, notes: [], status: "OK" }, d);
  }
  function renderGlance() {
    const PM = periodMap(); if (!PM[G_STATE.period]) G_STATE.period = "FY2026-27 Q1";
    $("#g-measure").innerHTML = [["gross", "Gross"], ["net", "Net"], ["refund", "Refunds"]].map(([k, t]) => `<button type="button" data-measure="${k}" aria-pressed="${G_STATE.measure === k}">${t}</button>`).join("");
    $("#g-period").innerHTML = Object.keys(PM).map(k => `<button type="button" data-period="${esc(k)}" aria-pressed="${G_STATE.period === k}">${esc(k)}</button>`).join("");
    const M = PM[G_STATE.period], meas = G_STATE.measure, color = meas === "net" ? "var(--net)" : meas === "refund" ? "var(--refund)" : "var(--gross)";
    const k = m => G.bounds(d, M, m, () => true);
    const g = k("gross"), n = k("net"), rf = k("refund");
    const missing = d.missing.filter(r => r.months.some(m => M.includes(m))).length;
    const tot = g.info.certain + g.info.ambiguous + g.info.conflicting_record_ids_in_window + g.info.unconvertible + missing, pct = tot ? g.info.certain / tot : 1;
    const rng = b => b.info.unconvertible ? `<span style="color:var(--refund)">can’t determine</span>` : b.lo === b.hi ? cu(G.cr(b.lo), "INR crore") : `${cu(G.cr(b.lo), "INR crore")}<span class="muted"> – </span><wbr>${cu(G.cr(b.hi), "INR crore")}`;
    const R = 26, circ = 2 * Math.PI * R;
    let h = `<div class="kpis">
      <div class="kpi"><span><i style="background:var(--gross)"></i>Gross collection</span><b>${rng(g)}</b><small>₹ crore · ${esc(G_STATE.period)}</small></div>
      <div class="kpi" style="animation-delay:60ms"><span><i style="background:var(--refund)"></i>Refunds</span><b>${rng(rf)}</b><small>booked to the original month</small></div>
      <div class="kpi" style="animation-delay:120ms"><span><i style="background:var(--net)"></i>Net collection</span><b>${rng(n)}</b><small>gross − refunds</small></div>
      <div class="kpi" style="animation-delay:180ms"><span>Records placed with certainty</span><div class="ring"><svg width="64" height="64" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="${R}" fill="none" stroke="var(--line)" stroke-width="7"/><circle cx="32" cy="32" r="${R}" fill="none" stroke="var(--marigold)" stroke-width="7" stroke-linecap="round" stroke-dasharray="${circ}" stroke-dashoffset="${circ * (1 - pct)}" transform="rotate(-90 32 32)" style="transition:stroke-dashoffset 1s"/></svg><b style="margin:0">${Math.round(pct * 100)}%</b></div><small>${g.info.certain} of ${tot}; the rest are ambiguous, conflicting, blank or have no FX rate</small></div></div>`;
    if (g.info.unconvertible) h += `<div class="board" style="margin-top:12px;background:var(--warn-bg);border-color:transparent"><b>Why some figures say “can’t determine”:</b> ${g.info.unconvertible} USD record(s) here fall in a month with no USD→INR rate in fx_rates.csv. Any total would include a guessed exchange rate.</div>`;
    const monthsAll = breakdown(null, meas, "month");
    const zones = breakdown(M, meas, "zone"), tax = breakdown(M, meas, "tax"), states = breakdown(M, meas, "state");
    h += `<div class="boards">
      <div class="board wide"><h2>Month by month</h2><p class="sub">${meas === "gross" ? "Gross collection" : meas === "net" ? "Net collection" : "Refunds"}, ₹ crore. Striped tops are what uncertain records might add; “?” means USD rows with no exchange rate.</p>${legendRange(color, meas)}${monthCols(monthsAll.items, "INR crore", color)}</div>
      <div class="board"><h2>Zone compass</h2><p class="sub">${esc(G_STATE.period)} · zones from states.csv</p>${compass(zones, color)}</div>
      <div class="board"><h2>Tax mix</h2><p class="sub">${esc(G_STATE.period)} · share by range midpoint</p>${donut(tax.items)}</div>
      <div class="board wide"><h2>States, honestly ranked</h2><p class="sub">${esc(G_STATE.period)} · ordered by midpoint. Where ranges overlap, the order isn’t proven.</p>${legendRange(color, meas)}${rangeRows(states.items, "INR crore", { color, W: slot("wide") })}</div></div>`;
    $("#glance").innerHTML = h;
    document.querySelectorAll("#glance .cu").forEach(countUp);
  }
  function compass(z, color) {
    const by = Object.fromEntries(z.items.map(i => [i.key, i])), max = Math.max(...z.items.map(i => toN(i.hi, "INR crore")), 1);
    const tile = (k, cls) => { const i = by[k]; return `<div class="zone ${cls}" data-tip="${esc(`${k}: ${i.range[0]} – ${i.range[1]} ₹ crore`)}"><b>${k}</b><span class="num">${i.exact ? fmtNum(i.range[0]) : fmtNum(i.range[0]) + " – " + fmtNum(i.range[1])}</span><div class="bar"><i style="width:${toN(i.hi, "INR crore") / max * 100}%;background:repeating-linear-gradient(45deg,${color} 0 3px,transparent 3px 6px)"></i><i style="width:${toN(i.lo, "INR crore") / max * 100}%;background:${color}"></i></div></div>`; };
    const un = z.unallocated;
    return `<div class="compass">${tile("North", "z-N")}${tile("West", "z-W")}<div class="zone z-C"><b style="font-size:13px">Unallocated</b><span class="num">${un && un.states.length ? esc(un.states.join(", ")) + "<br>" + (un.lo === un.hi ? fmtNum(G.cr(un.lo)) : fmtNum(G.cr(un.lo)) + " – " + fmtNum(G.cr(un.hi))) : "—"}</span></div>${tile("East", "z-E")}${tile("South", "z-S")}</div>
      ${z.contradictoryStates?.length ? z.contradictoryStates.map(c => `<div class="thread"><span class="tag cf">contradiction</span><span>${esc(c.state)} is listed in both ${esc(c.zones.join(" and "))}, so it only adds to their upper bounds (${esc(c.range[0])} – ${esc(c.range[1])}).</span></div>`).join("") : ""}`;
  }
  function donut(items) {
    const cols = ["var(--gross)", "var(--marigold)", "var(--net)", "var(--refund)"], mids = items.map(i => (toN(i.lo, "INR crore") + toN(i.hi, "INR crore")) / 2), tot = mids.reduce((a, b) => a + b, 0) || 1;
    const R = 62, circ = 2 * Math.PI * R; let off = 0;
    const segs = items.map((it, k) => { const len = mids[k] / tot * circ, seg = `<circle cx="90" cy="90" r="${R}" fill="none" stroke="${cols[k % 4]}" stroke-width="26" stroke-dasharray="${Math.max(0, len - 3)} ${circ}" stroke-dashoffset="${-off}" transform="rotate(-90 90 90)" style="animation:spin .9s ${k * 90}ms both" data-tip="${esc(`${it.label}: ${it.range[0]} – ${it.range[1]} ₹ crore · ${(mids[k] / tot * 100).toFixed(1)}%`)}"/>`; off += len; return seg; }).join("");
    return `<style>@keyframes spin{from{stroke-dasharray:0 ${circ}}}</style><div style="display:flex;flex-wrap:wrap;gap:18px;align-items:center"><svg width="180" height="180" viewBox="0 0 180 180" role="img" aria-label="tax mix">${segs}<text x="90" y="86" text-anchor="middle" style="fill:var(--muted);font:11px var(--mono)">midpoint</text><text x="90" y="104" text-anchor="middle" style="fill:var(--ink);font:600 15px var(--mono)">${short(tot)} cr</text></svg>
      <div style="display:grid;gap:8px;min-width:0;flex:1 1 180px">${items.map((it, k) => `<div style="display:flex;flex-wrap:wrap;gap:4px 10px;align-items:baseline;font-size:14px;min-width:0"><i style="width:12px;height:12px;border-radius:3px;background:${cols[k % 4]};flex:none;display:inline-block"></i><b style="min-width:52px">${esc(it.label)}</b><span class="num muted" style="font-size:12.5px">${it.exact ? fmtNum(it.range[0]) : fmtNum(it.range[0]) + " – " + fmtNum(it.range[1])}</span><span class="num" style="margin-left:auto">${(mids[k] / tot * 100).toFixed(1)}%</span></div>`).join("")}</div></div>`;
  }

  /* ------------------------------------------------------------------ traps */
  function renderTraps() {
    const C0 = T.collections, legacyAmb = C0.filter(r => r.source_system === "legacy" && (() => { const [a, b] = r.collection_date.split("/").map(Number); return a <= 12 && b <= 12 && a !== b; })());
    const usd = C0.filter(r => r.currency === "USD" || r.amount.includes("$")), blankC = C0.filter(r => !r.currency);
    const sample = s => C0.find(r => r.source_system === s && r.amount);
    const zoneDup = Object.entries(d.zmap).filter(([, z]) => z.size > 1);
    const orphanStates = [...new Set(C0.map(r => r.state_code))].filter(s => !d.zmap[s]);
    const fxMonths = new Set(Object.keys(d.fx)), noFx = [...new Set(d.recs.filter(r => r.ccy === "USD" && r.months.some(m => !fxMonths.has(m))).flatMap(r => r.months.filter(m => !fxMonths.has(m))))];
    let mism = 0; for (const m of d.certainMonths) { const o = G.run({ question: "", measure: "net", unit: "crore", months: [m], periods: [[m]], states: [], zone: null, tax: null, source: null, shape: "reconcile", groupBy: null, notes: [], status: "OK" }, d); mism += o.answer?.confirmed_mismatch?.length || 0; }
    const row = r => Object.values(r).join(",");
    const cards = [
      ["Units don’t match", usd.length + blankC.length, `${row(usd[0])}\n${row(blankC[0])}`, `${usd.length} rows are in USD, and ${blankC.length} leave the currency blank, so it’s read from the symbol (₹, Rs., $). USD is converted at the collection month’s rate.`, "USD value of total IGST collected in FY2026-27 Q1."],
      ["Three number formats", 3, `${sample("gst_portal").amount}   ← portal, Indian grouping\n${sample("state_treasury").amount}   ← treasury, . thousands , decimals\n${sample("legacy").amount}   ← legacy, no separators`, "Each source has its own number style. Reading every one the same way would be off by a factor of 100 or more.", "Total gross collection, all sources, FY2026-27 Q1, INR crore."],
      ["Dates are ambiguous", legacyAmb.length, legacyAmb.slice(0, 2).map(row).join("\n"), "The legacy system’s date format is undocumented. 05/06/2026 could be May or June, so these rows count only toward upper bounds.", "Total gross collection in April 2026, INR crore."],
      ["Rows are duplicated", d.exactDupes.reduce((a, x) => a + x.copies, 0), d.exactDupes.slice(0, 1).map(x => row(T.collections.find(r => r.record_id === x.id)) + "   ×2").join(""), "Exact re-exports are dropped, so each record counts once.", "How many records were collected in January 2026?"],
      ["Same ID, different amounts", Object.keys(d.conflicts).length, Object.entries(d.conflicts).slice(0, 1).map(([id, v]) => v.map(x => row(x.raw)).join("\n")).join(""), "When a record ID appears with conflicting amounts, neither version can be trusted. Only the larger one goes into the upper bound.", "Gross collection in March 2026"],
      ["Tables contradict", zoneDup.length + mism, `${zoneDup.map(([s, z]) => `${s} → ${[...z].join(" / ")}`).join("\n")}\nmonthly_summary mismatches: ${mism}`, "states.csv puts a state in two zones, and the manual monthly summary disagrees with the system of record in places. The desk shows both, never silently picks one.", "Which state figures in monthly_summary.csv for 2026-03 contradict collections.csv (system of record)?"],
      ["Data is missing", d.missing.length, d.missing.slice(0, 2).map(x => row(x.raw)).join("\n"), "Blank amounts are excluded and named in the warnings. Above 10% of a window, the desk refuses.", "Total gross collection recorded by source_system=gst_portal in FY2026-27 Q1, INR crore."],
      ["Orphans", orphanStates.length + d.orphanRefunds.length, `state_code not in states.csv: ${orphanStates.join(", ")}\nrefunds for unknown records: ${d.orphanRefunds.slice(0, 4).join(", ")}`, "Collections with an unknown state are reported as “unallocated” instead of being forced into a zone. Refunds for records that don’t exist are not deducted.", "Gross collection by zone, FY2026-27 Q1, INR crore (zone from states.csv)."],
      ["No valid answer", noFx.length + 2, `USD rows with no FX rate in: ${noFx.map(G.monthLabel).join(", ")}\nno population column · no prior year`, "July has USD collections but no exchange rate. There is no population data and no 2025 baseline. These questions get a reasoned “can’t determine”.", "Total gross collection in July 2026 (INR crore)."],
      ["Designed to trick you", 1, "“FY2026-27 Q5”, “Q1” with no year, “last month”", "Invalid quarters are named as invalid; ambiguous or relative periods are sent back to you instead of guessed.", "Gross collection for FY2026-27 Q5."],
    ];
    $("#traps").innerHTML = cards.map(([t, n, ex, how, q], i) => `<article class="trap-card" style="animation-delay:${i * 50}ms"><header><h3>${esc(t)}</h3><span class="count">${n}</span></header><code>${esc(ex)}</code><p>${esc(how)}</p><button class="btn" type="button" data-q="${esc(q)}">Show me →</button></article>`).join("");
  }

  /* ------------------------------------------------------------------- data */
  function renderData() {
    $("#tables").innerHTML = Object.keys(ROLE_FILE).map((role, i) => {
      const rows = T[role] || [], src = T._src[role], cols = rows[0] ? Object.keys(rows[0]) : [];
      return `<article class="tcard" style="animation-delay:${i * 50}ms"><header><h3>${esc(src?.name || ROLE_FILE[role])}</h3><span class="tag ok">detected: ${esc(role.replace("_", " "))}</span></header>
        <p class="muted" style="margin:6px 0 0;font-size:13.5px">${rows.length} rows · ${cols.length} columns · ${src?.builtIn ? "built in" : "uploaded"}</p>
        <div class="tbl" style="max-height:190px"><table><thead><tr>${cols.map(c => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${rows.slice(0, 5).map(r => `<tr>${cols.map(c => `<td>${esc(r[c])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>
        <button class="btn" type="button" data-copycsv="${role}" style="margin-top:10px">Copy CSV</button></article>`;
    }).join("");
    $("#rules").innerHTML = [
      "Reporting currency is INR; headline figures are in INR crore (1 crore = 10,000,000).",
      "USD amounts are converted at the month-average rate in fx_rates.csv for the collection month. No rate → no conversion → no answer.",
      "Fiscal year starts 1 April: FY Q1 = Apr–Jun, Q2 = Jul–Sep, Q3 = Oct–Dec, Q4 = Jan–Mar. There are exactly four quarters.",
      "Date formats: gst_portal DD/MM/YYYY, state_treasury MM/DD/YYYY, legacy undocumented (both readings kept when ambiguous).",
      "Number formats: gst_portal Indian grouping, state_treasury “.” thousands and “,” decimals, legacy no separators.",
      "Gross = sum of amounts. Net = gross − refunds, with refunds booked to the month of the original collection.",
      "collections.csv is the system of record; monthly_summary.csv is a manual export and is only checked against it.",
      "Exact duplicate rows are dropped. Conflicting re-exports of one record ID count only toward the upper bound.",
    ].map(r => `<li>${esc(r)}</li>`).join("");
    $("#dict").textContent = DICT_SRC;
  }
  async function readFiles(files) {
    const msgs = [];
    for (const f of files) {
      const text = await f.text(), rows = G.parseCSV(text), role = rows[0] && G.detectRole(Object.keys(rows[0]));
      if (!role) { msgs.push(`${f.name}: headers don’t match any known table, so it was skipped.`); continue; }
      T[role] = rows; T._src[role] = { name: f.name, text, builtIn: false }; msgs.push(`${f.name} → ${role.replace("_", " ")} (${rows.length} rows)`);
    }
    try { d = G.load(T); window.GPD_DATA = d; $("#dropmsg").textContent = msgs.join(" · ") || "Nothing loaded."; }
    catch (e) { $("#dropmsg").textContent = "Couldn’t read that data: " + e.message + ". Built-in data restored."; loadBuiltIn(); }
    renderData(); $("#answer").innerHTML = ""; $("#trail").innerHTML = "";
  }

  /* ----------------------------------------------------------------- events */
  document.addEventListener("click", async e => {
    const t = e.target.closest("button"); if (!t) return;
    if (t.dataset.q) { tab("ask"); window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" }); ask(t.dataset.q); }
    else if (t.id?.startsWith("t-")) tab(t.id.slice(2));
    else if (t.dataset.measure) { G_STATE.measure = t.dataset.measure; renderGlance(); }
    else if (t.dataset.period) { G_STATE.period = t.dataset.period; renderGlance(); }
    else if (t.dataset.copy || t.dataset.copycsv) {
      const txt = t.dataset.copy ? lastPython : T._src[t.dataset.copycsv]?.text || "";
      const old = t.textContent;
      try { await navigator.clipboard.writeText(txt); t.textContent = "Copied ✓"; }
      catch (err) { if (t.dataset.copy) { const r = document.createRange(); r.selectNodeContents($("#pycode")); getSelection().removeAllRanges(); getSelection().addRange(r); } t.textContent = "Selected: press Ctrl+C"; }
      setTimeout(() => (t.textContent = old), 1800);
    }
  });
  $("#qform").addEventListener("submit", e => { e.preventDefault(); ask($("#q").value); });
  $("#file").addEventListener("change", e => { readFiles([...e.target.files]); e.target.value = ""; });
  const drop = $("#drop");
  ["dragenter", "dragover"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", e => readFiles([...e.dataTransfer.files]));
  const tip = $("#tip");
  document.addEventListener("mousemove", e => {
    const t = e.target.closest?.("[data-tip]"); if (!t) { tip.hidden = true; return; }
    tip.textContent = t.getAttribute("data-tip"); tip.hidden = false;
    tip.style.left = Math.min(e.clientX + 14, innerWidth - tip.offsetWidth - 8) + "px";
    tip.style.top = (e.clientY + 18 + tip.offsetHeight > innerHeight ? e.clientY - tip.offsetHeight - 10 : e.clientY + 18) + "px";
  });
  let rz, lastW = vw();
  addEventListener("resize", () => { clearTimeout(rz); rz = setTimeout(() => { if (Math.abs(vw() - lastW) < 40) return; lastW = vw(); if (!$("#v-glance").hidden) renderGlance(); if ($("#q").value && !$("#v-ask").hidden && $("#answer").innerHTML) { const o = G.ask($("#q").value, d); renderAnswer(o); } }, 220); });

  loadBuiltIn(); renderChips();
  let start = "ask"; try { start = localStorage.getItem("gpd-tab") || "ask"; } catch (e) { /* ignore */ }
  tab(["ask", "glance", "traps", "data"].includes(start) ? start : "ask");
  ask(ELEVEN[1][1]);
})();
