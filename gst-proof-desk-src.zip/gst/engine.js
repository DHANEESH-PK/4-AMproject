/* GST Proof engine — exact port of pda_common.py (rules from data_dictionary.md) + question layer.
   Money is BigInt in units of 1e-16 so sums are exact, like Python's Decimal. */
(function (root) {
  "use strict";
  const G = {};
  const S16 = 10n ** 16n, CRORE_U = 10n ** 7n * S16;
  const FY_Q = { 1: ["04", "05", "06"], 2: ["07", "08", "09"], 3: ["10", "11", "12"], 4: ["01", "02", "03"] };
  const MONTHS = ["january","february","march","april","may","june","july","august","september","october","november","december"];
  const MSHORT = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  G.monthLabel = k => `${MSHORT[+k.slice(5) - 1]} ${k.slice(0, 4)}`;
  G.ZONES = ["North", "South", "East", "West"];
  G.TAXES = ["CGST", "SGST", "IGST", "CESS"];
  G.SOURCES = { gst_portal: "GST portal", state_treasury: "State treasury", legacy: "Legacy system" };

  /* ---------- CSV ---------- */
  G.parseCSV = function (text) {
    text = text.replace(/^﻿/, "");
    const rows = []; let row = [], cell = "", q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
      else if (c === '"') q = true;
      else if (c === ",") { row.push(cell); cell = ""; }
      else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; row.push(cell); cell = ""; if (row.some(x => x !== "")) rows.push(row); row = []; }
      else cell += c;
    }
    row.push(cell); if (row.some(x => x !== "")) rows.push(row);
    const headers = rows.shift() || [];
    return rows.map(r => Object.fromEntries(headers.map((h, i) => [h, r[i] ?? ""])));
  };
  /* auto-detect which table a CSV is, from its headers */
  G.detectRole = function (headers) {
    const h = new Set(headers.map(x => x.trim().toLowerCase()));
    if (h.has("record_id") && h.has("collection_date") && h.has("amount")) return "collections";
    if (h.has("refund_id") && h.has("record_id")) return "refunds";
    if (h.has("state_code") && h.has("zone")) return "states";
    if (h.has("from_ccy") && h.has("rate")) return "fx_rates";
    if (h.has("net_revenue_inr_crore")) return "monthly_summary";
    return null;
  };

  /* ---------- decimal helpers ---------- */
  function toUnits(t) {               // "1234.5" -> BigInt units (throws like Decimal() on junk)
    const m = /^\s*([+-]?)(\d*)(?:\.(\d*))?\s*$/.exec(t);
    if (!m || (m[2] === "" && (m[3] === undefined || m[3] === ""))) throw new Error(`invalid amount “${t}”`);
    const frac = (m[3] || "").padEnd(16, "0").slice(0, 16);
    const v = BigInt(m[2] || "0") * S16 + BigInt(frac);
    return m[1] === "-" ? -v : v;
  }
  function roundDiv(a, b) {           // round half away from zero (ROUND_HALF_UP)
    const neg = (a < 0n) !== (b < 0n); a = a < 0n ? -a : a; b = b < 0n ? -b : b;
    let q = a / b; if ((a % b) * 2n >= b) q += 1n; return neg ? -q : q;
  }
  const fix2 = c => { const neg = c < 0n; c = neg ? -c : c; return (neg ? "-" : "") + (c / 100n) + "." + String(c % 100n).padStart(2, "0"); };
  G.cr = x => fix2(roundDiv(x * 100n, CRORE_U));          // INR crore, 2 dp
  G.q2 = x => fix2(roundDiv(x * 100n, S16));              // plain 2 dp
  G.num = s => Number(s);

  /* ---------- pda_common port ---------- */
  G.parseAmount = function (text, ccy, source) {
    let t = (text || "").trim();
    if (!t) return [null, null];
    let sym = null;
    for (const [s, c] of [["₹", "INR"], ["Rs.", "INR"], ["$", "USD"]]) if (t.includes(s)) { sym = c; t = t.split(s).join(""); }
    ccy = (ccy || "").trim().toUpperCase() || sym;
    if (sym && ccy !== sym) throw new Error("currency/symbol conflict");
    t = t.trim();
    t = source === "state_treasury" ? t.split(".").join("").replace(/,/g, ".") : t.split(",").join("");
    return [toUnits(t), ccy];
  };
  G.possibleMonths = function (text, source) {
    const [a0, b0, y] = text.split("/"); const a = parseInt(a0, 10), b = parseInt(b0, 10);
    let opts;
    if (source === "gst_portal") opts = [[y, b]];
    else if (source === "state_treasury") opts = [[y, a]];
    else opts = a > 12 ? [[y, b]] : b > 12 ? [[y, a]] : [[y, a], [y, b]];
    return [...new Set(opts.map(([yy, mm]) => `${yy}-${String(mm).padStart(2, "0")}`))].sort();
  };
  G.fyQuarterMonths = function (fyStart, q) {
    if (!FY_Q[q]) throw new Error("fiscal quarter must be 1..4");
    return FY_Q[q].map(m => `${fyStart + (q === 4 ? 1 : 0)}-${m}`);
  };

  G.load = function (T) {
    const fx = {};
    for (const r of T.fx_rates) if (r.from_ccy === "USD" && r.to_ccy === "INR") fx[r.month] = { h: toUnits(r.rate) / (S16 / 100n), s: r.rate };
    const groups = new Map();
    for (const r of T.collections) { if (!groups.has(r.record_id)) groups.set(r.record_id, []); groups.get(r.record_id).push(r); }
    const recs = [], conflicts = {}, missing = [], exactDupes = [], errors = [];
    for (const [rid, rows] of groups) {
      const uniq = new Map();
      for (const x of rows) { const k = JSON.stringify(Object.entries(x).sort()); uniq.set(k, x); }
      if (uniq.size < rows.length) exactDupes.push({ id: rid, copies: rows.length - uniq.size });
      const parsed = [];
      for (const x of uniq.values()) {
        let amt, ccy;
        try { [amt, ccy] = G.parseAmount(x.amount, x.currency, x.source_system); }
        catch (e) { errors.push({ id: rid, why: e.message }); continue; }
        parsed.push({ id: rid, state: x.state_code, tax: x.tax_type, source: x.source_system, amt, ccy,
                      months: G.possibleMonths(x.collection_date, x.source_system), raw: x });
      }
      if (!parsed.length) continue;
      if (parsed.length > 1) { conflicts[rid] = parsed; continue; }
      if (parsed[0].amt === null) { missing.push(parsed[0]); continue; }
      recs.push(parsed[0]);
    }
    const refunds = {};
    for (const r of T.refunds) (refunds[r.record_id] ||= []).push(toUnits(r.amount));
    const ids = new Set(recs.map(r => r.id));
    const orphanRefunds = Object.keys(refunds).filter(k => !ids.has(k) && !(k in conflicts));
    for (const r of recs) r.refund = (refunds[r.id] || []).reduce((a, b) => a + b, 0n);
    const zmap = {};
    for (const r of T.states) (zmap[r.state_code] ||= new Set()).add(r.zone);
    const stateName = {}; for (const r of T.states) stateName[r.state_code] = r.state_name;
    const allMonths = [...new Set(recs.flatMap(r => r.months))].sort();
    const certainMonths = [...new Set(recs.filter(r => r.months.length === 1).map(r => r.months[0]))].sort();
    return { fx, recs, conflicts, missing, orphanRefunds, exactDupes, errors, zmap, stateName, allMonths, certainMonths, T };
  };

  G.value = function (rec, month, measure, fx, toUsd) {
    const rate = fx[month];
    if (rec.ccy === "USD" && !rate) return null;
    if (toUsd && !rate) return null;
    const base = measure === "refund" ? rec.refund : rec.amt - (measure === "net" ? rec.refund : 0n);
    const inr = rec.ccy === "USD" ? base * rate.h / 100n : base;
    return toUsd ? inr * 100n / rate.h : inr;
  };

  G.bounds = function (d, months, measure = "gross", pred = () => true, toUsd = false) {
    let lo = 0n, hi = 0n; const info = { certain: 0, ambiguous: 0, unconvertible: 0 };
    const rows = { certain: [], ambiguous: [], unconvertible: [], conflict: [] };
    const W = new Set(months);
    const maxOf = a => a.reduce((x, y) => (y > x ? y : x)), minOf = a => a.reduce((x, y) => (y < x ? y : x));
    for (const r of d.recs) {
      if (!pred(r)) continue;
      const ins = r.months.filter(m => W.has(m));
      if (!ins.length) continue;
      const vals = r.months.map(m => G.value(r, m, measure, d.fx, toUsd));
      if (ins.map(m => G.value(r, m, measure, d.fx, toUsd)).some(v => v === null)) { info.unconvertible++; rows.unconvertible.push(r); continue; }
      if (ins.length === r.months.length) { lo += minOf(vals); hi += maxOf(vals); info.certain++; rows.certain.push(r); }
      else { hi += maxOf(ins.map(m => G.value(r, m, measure, d.fx, toUsd))); info.ambiguous++; rows.ambiguous.push(r); }
    }
    info.conflicting_record_ids_in_window = 0;
    for (const [rid, versions] of Object.entries(d.conflicts)) {
      const cand = []; for (const v of versions) for (const m of v.months) if (W.has(m) && pred(v)) cand.push([v, m]);
      if (cand.length) {
        const vals = cand.map(([v, m]) => G.value({ ...v, refund: 0n }, m, measure, d.fx, toUsd)).filter(x => x !== null);
        if (vals.length) { hi += maxOf(vals); info.conflicting_record_ids_in_window++; rows.conflict.push(rid); }
      }
    }
    return { lo, hi, info, rows };
  };

  /* ---------- question analyzer ---------- */
  const KNOWN = new Set(`what was were is are the a an in for of on to during from at and with by than vs versus which who how
    much many total sum overall gross net collection collections collected collect revenue revenues tax taxes gst amount amounts value
    refund refunds refunded booked original month months monthly quarter quarters fiscal fy calendar year state states zone zones
    region regions north south east west cgst sgst igst cess portal treasury legacy source sources system systems recorded all
    inr crore crores rupees rupee rs usd dollars dollar us top highest lowest largest smallest biggest best worst rank ranking ranked
    each per breakdown split show list give tell me our we did do does has have had compare compared higher lower more less greater
    exceed exceeded above below over under growth grow grew change yoy year-on-year prior previous same summary summaries figures
    figure csv data contradict contradicts contradicting match matches reconcile mismatch system of record records how-many count
    number transactions entries please only between through until -- whose`.split(/\s+/));
  const STATE_ALIASES = { maharashtra: "MH", gujarat: "GJ", karnataka: "KA", "tamil nadu": "TN", tamilnadu: "TN", kerala: "KL", delhi: "DL",
    "uttar pradesh": "UP", rajasthan: "RJ", "west bengal": "WB", odisha: "OD", orissa: "OD", telangana: "TG" };

  G.analyze = function (question, d) {
    const spec = { question, status: null, reason: null, measure: "gross", unit: "crore", months: null, monthsLabel: "",
                   states: [], zone: null, tax: null, source: null, shape: "total", groupBy: null, topN: null, topDir: "desc",
                   compare: null, threshold: null, op: null, notes: [] };
    const stop = (status, reason, fix) => Object.assign(spec, { status, reason, fix });
    let q = " " + question.toLowerCase().replace(/[_=]/g, " ").replace(/(\d),(\d)/g, "$1$2") + " ";
    q = q.replace(/\bmonthly summary\.csv|monthly summary csv/g, " monthly summary ").replace(/\b(collections|states|refunds|fx rates)\.csv\b/g, " $1 ");
    if (!question.trim()) return stop("INVALID_QUESTION", "Type a question first.");
    // causal / forecast / relative
    if (/\b(why|cause[sd]?|because|reason|predict|forecast|will|should|next year|recommend)\b/.test(q))
      return stop("CANNOT_DETERMINE", "This asks why something happened or what will happen. The ledger records amounts, not causes or the future.", "Ask for the figures behind it, e.g. “Net collection by state in April 2026”.");
    if (/\b(last|this|current|previous|past|recent)\s+(month|quarter|year|week)\b|\b(ytd|mtd|today|yesterday|lately)\b/.test(q) && !/\bprevious year\b|\bprior year\b/.test(q))
      return stop("CANNOT_DETERMINE", "The period is relative (“last month”, “YTD”…). Relative to which date? The data doesn’t say what today is.", "Name the month or quarter, e.g. “FY2026-27 Q1” or “April 2026”.");
    // drop restating parentheticals when the main text already has a period
    const main = q.replace(/\([^)]*\)/g, " ");
    const hasPeriod = s => /\bfy|\bq\d|\b20\d\d\b|\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/.test(s);
    if (hasPeriod(main)) q = main;

    // measure
    if (/\bnet\b|after refunds?/.test(q)) spec.measure = "net";
    else if (/\brefund(s|ed)?\b/.test(q) && !/\brefunds? booked\b/.test(q)) spec.measure = "refund";
    if (/\b(usd|dollars?|us\$|\$)\b|\busd\b/.test(q) || /\$/.test(question)) spec.unit = "usd";
    if (spec.unit === "usd" && spec.measure !== "gross") spec.notes.push("USD figures are converted at each month’s USD→INR rate.");

    // entities
    for (const [name, code] of Object.entries(STATE_ALIASES)) if (new RegExp(`\\b${name}\\b`).test(q)) spec.states.push(code);
    for (const code of Object.keys(d.zmap).concat(["TG"])) if (new RegExp(`\\b${code.toLowerCase()}\\b`).test(q) && !["up"].includes(code.toLowerCase())) spec.states.push(code);
    if (/\bup\b/.test(q) && /\b(state|uttar)\b/.test(q)) spec.states.push("UP");
    spec.states = [...new Set(spec.states)];
    const zm = q.match(/\b(north|south|east|west)\b(?!\s+bengal)/); if (zm && /\b(zone|region)\b/.test(q) || (zm && !/\bby zone\b/.test(q) && /\b(north|south|east|west) (zone|region)\b/.test(q))) spec.zone = zm[1][0].toUpperCase() + zm[1].slice(1);
    const tm = q.match(/\b(cgst|sgst|igst|cess)\b/); if (tm) spec.tax = tm[1].toUpperCase();
    if (/\bgst portal\b/.test(q)) spec.source = "gst_portal"; else if (/\b(state )?treasury\b/.test(q)) spec.source = "state_treasury"; else if (/\blegacy\b/.test(q)) spec.source = "legacy";

    // shape
    const top = q.match(/\btop[\s-]*(\d+)\b/) || q.match(/\b(highest|largest|biggest|best|most)\b/) && ["", "1"] || q.match(/\b(lowest|smallest|worst|least)\b/) && ["", "-1"];
    if (/\b(monthly summary|summary)\b/.test(q) && /\b(contradict|match|reconcile|mismatch|agree|differ)/.test(q)) spec.shape = "reconcile";
    else if (/\b(yoy|year-on-year|year on year|growth|grew|same quarter last year|prior year|previous year)\b/.test(q)) spec.shape = "yoy";
    else if (top) { spec.shape = "top"; spec.topN = Math.abs(+top[1]) || 1; spec.topDir = +top[1] < 0 ? "asc" : "desc";
      const after = (q.match(/\b(?:top[\s-]*\d+|highest|largest|biggest|best|most|lowest|smallest|worst|least)\s+(?:\w+\s+){0,2}?(states?|zones?|regions?|tax types?|taxes|months?|sources?)\b/) || [])[1] || "";
      spec.groupBy = /^(zone|region)/.test(after) ? "zone" : /^tax/.test(after) ? "tax" : /^month/.test(after) ? "month" : /^source/.test(after) ? "source" : /^state/.test(after) ? "state"
        : /\b(zone|region)s?\b/.test(q) ? "zone" : /\btax types?\b/.test(q) ? "tax" : /\bsources?\b/.test(q) ? "source" : /^\s*which month\b/.test(q) ? "month" : "state"; }
    else if ((!spec.source || !/\bby source/.test(q)) && /\bby (state|zone|region|month|tax|tax type|source|source system)s?\b(?! (gst|state treasury|treasury|legacy))|\b(state|zone|month|tax)[- ]wise\b|\beach (state|zone|month)\b|\bper (state|zone|month)\b|\bbreakdown\b/.test(q)) {
      const g = (q.match(/\b(?:by|each|per) (state|zone|region|month|tax|source)|\b(state|zone|month|tax)[- ]wise/) || [])[1] || (q.match(/\b(state|zone|month|tax)[- ]wise/) || [])[1] || "state";
      spec.shape = "breakdown"; spec.groupBy = g === "region" ? "zone" : g;
    }
    if (/\bhow many\b|\bnumber of (records|transactions|entries)\b|\bcount\b/.test(q)) spec.shape = spec.shape === "total" ? "count" : spec.shape;

    // period
    const periods = [];
    const fyRe = /\bfy\s?'?(\d{2,4})(?:\s?[-–\/]\s?(\d{2,4}))?/g;
    const fys = [...q.matchAll(fyRe)];
    const qs = [...q.matchAll(/\bq\s?(\d+)\b/g)];
    const calQ = /\bcalendar\b/.test(q);
    if (qs.length) {
      for (const m of qs) { const n = +m[1]; if (n < 1 || n > 4) return stop("INVALID_QUESTION", `There is no Q${n}. A fiscal year has exactly four quarters (data dictionary: FY Q1–Q4).`, "Use Q1, Q2, Q3 or Q4."); }
      if (calQ) {
        const y = +(q.match(/\b(20\d\d)\b/) || [])[1]; if (!y) return stop("CANNOT_DETERMINE", "Calendar quarter needs a year.", "e.g. “calendar Q1 2026”.");
        for (const m of qs) periods.push([0, 1, 2].map(i => `${y}-${String(3 * (+m[1] - 1) + 1 + i).padStart(2, "0")}`));
      } else {
        if (!fys.length) return stop("CANNOT_DETERMINE", `“Q${qs[0][1]}” alone is ambiguous: the fiscal year starts 1 April, so Q${qs[0][1]} could belong to FY2025-26 or FY2026-27 — or you may mean a calendar quarter.`, `Say “FY2026-27 Q${qs[0][1]}” or “calendar Q${qs[0][1]} 2026”.`);
        if (fys.length !== qs.length && !(fys.length === 1)) return stop("CANNOT_DETERMINE", "I can’t pair each quarter with its fiscal year.", "Write each as “FY2026-27 Q1”.");
        for (let i = 0; i < qs.length; i++) {
          const f = fys[Math.min(i, fys.length - 1)];
          let a = +f[1], b = f[2] ? +f[2] : null, start;
          if (a < 100) a += 2000; if (b !== null && b < 100) b += 2000;
          if (b !== null) { if (b !== a + 1) return stop("INVALID_QUESTION", `FY${f[1]}-${f[2]} is not a valid fiscal year (it must span two consecutive years).`, "e.g. FY2026-27."); start = a; }
          else if (String(f[1]).length === 2) { start = a - 1; spec.notes.push(`“FY${f[1]}” read as FY${start}-${String(a).slice(2)} (the year it ends), the usual Indian convention.`); }
          else return stop("CANNOT_DETERMINE", `“FY${f[1]}” is ambiguous: it could mean FY${a - 1}-${String(a).slice(2)} or FY${a}-${String(a + 1).slice(2)}.`, `Write it as “FY${a}-${String(a + 1).slice(2)}”.`);
          periods.push(G.fyQuarterMonths(start, +qs[i][1]));
        }
      }
    } else if (fys.length) {
      // whole fiscal year
      const f = fys[0]; let a = +f[1], b = f[2] ? +f[2] : null; if (a < 100) a += 2000; if (b !== null && b < 100) b += 2000;
      const start = b !== null ? a : String(f[1]).length === 2 ? a - 1 : null;
      if (start === null) return stop("CANNOT_DETERMINE", `“FY${f[1]}” is ambiguous (FY${a - 1}-${String(a).slice(2)} or FY${a}-${String(a + 1).slice(2)}).`, `Write “FY${a}-${String(a + 1).slice(2)}”.`);
      periods.push([1, 2, 3, 4].flatMap(n => G.fyQuarterMonths(start, n)));
    } else {
      const iso = [...q.matchAll(/\b(20\d\d)-(\d{2})\b/g)].map(m => { const mm = +m[2]; return mm >= 1 && mm <= 12 ? `${m[1]}-${m[2]}` : "bad"; });
      if (iso.includes("bad")) return stop("INVALID_QUESTION", "That month doesn’t exist (months run 01–12).");
      const mt = [...q.matchAll(/\b(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept|sep|oct|nov|dec)\b/g)]
        .map(m => MONTHS.findIndex(x => x.startsWith(m[1].slice(0, 3))) + 1);
      const years = [...q.matchAll(/\b(20\d\d)\b(?!-\d)/g)].map(m => +m[1]);
      if (mt.length) {
        let y = years[0];
        if (!y) { const ys = [...new Set(d.certainMonths.map(m => +m.slice(0, 4)))]; if (ys.length !== 1) return stop("CANNOT_DETERMINE", "Which year?", "Add the year."); y = ys[0]; spec.notes.push(`No year given; the data only covers ${y}.`); }
        const range = mt.length === 2 && (/\b(from|between)\b/.test(q) || /(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*(-|–|to|through|until)\s*(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/.test(q)) && !/\b(than|vs|versus|compared)\b/.test(q);
        if (range) { const [a, b] = [...mt].sort((x, z) => x - z); periods.push(Array.from({ length: b - a + 1 }, (_, i) => `${y}-${String(a + i).padStart(2, "0")}`)); }
        else mt.forEach(m => periods.push([`${y}-${String(m).padStart(2, "0")}`]));
      } else if (iso.length) iso.forEach(m => periods.push([m]));
      else if (years.length === 1) { periods.push(Array.from({ length: 12 }, (_, i) => `${years[0]}-${String(i + 1).padStart(2, "0")}`)); spec.notes.push(`“${years[0]}” read as calendar year Jan–Dec ${years[0]}.`); }
      else if (/\bh[12]\b/.test(q)) return stop("CANNOT_DETERMINE", "“H1/H2” is ambiguous here: calendar half or fiscal half (the fiscal year starts in April)?", "Name the months, e.g. “from April to June 2026”.");
    }
    if (!periods.length) {
      if (spec.shape === "reconcile") return stop("CANNOT_DETERMINE", "Which month should I reconcile?", "e.g. “Which state figures in monthly_summary for 2026-03 contradict collections?”");
      periods.push(null);
    }

    // unknown concepts → check every column like the reference Q09
    const words = q.replace(/[^a-z0-9\-\s]/g, " ").split(/\s+/).filter(Boolean);
    const stateWords = new Set(Object.keys(STATE_ALIASES).flatMap(s => s.split(" ")).concat(Object.keys(d.zmap).map(s => s.toLowerCase()), ["tg", "bengal", "pradesh", "nadu", "tamil", "uttar"]));
    const left = words.filter(w => !KNOWN.has(w) && !stateWords.has(w) && !/^\d/.test(w) && !/^(q\d+|fy[\d'\-–\/]*|top-?\d+|20\d\d(-\d+)?|\d+(-\d+)?)$/.test(w) &&
      !MONTHS.includes(w) && !MONTHS.some(m => m.slice(0, 3) === w || w === "sept") && !/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)$/.test(w));
    if (left.length) {
      const cols = [...new Set(Object.values(d.T).flatMap(t => Object.keys(t[0] || {})))].sort();
      const hit = left.some(w => cols.some(c => c.includes(w)));
      if (!hit) return stop("CANNOT_DETERMINE", `I can’t find “${left.join("”, “")}” anywhere in the data. Columns checked: ${cols.join(", ")}.${/capita|population/.test(q) ? " Per-capita figures need population per state, and no table has it." : ""}`, `Ask about collections, refunds or net — by state, zone, tax type, source or month. States in the data: ${Object.keys(d.stateName).map(k => d.stateName[k]).join(", ")}, plus TG (not in states.csv).`);
    }

    spec.periods = periods; spec.months = periods[0];
    if (periods.length === 2 && spec.shape === "total") spec.shape = "compare";
    if (periods.length > 2) return stop("CANNOT_DETERMINE", "Too many periods in one question.", "Ask one period, or two to compare.");
    if (/\b(exceed|exceeded|above|over|more than|greater than|below|under|less than)\b/.test(q) && spec.shape === "total") {
      const n = q.replace(/\b20\d\d(-\d+)?\b|\bq\d\b|\bfy\s?\d+(-\d+)?/g, " ").match(/\b(\d+(?:\.\d+)?)\s*(crore|cr|lakh|million|bn|billion)?\b/);
      if (n) { spec.shape = "threshold"; spec.op = /\b(below|under|less than)\b/.test(q) ? "lt" : "gt";
        let v = +n[1]; const u = n[2] || (spec.unit === "usd" ? "" : "crore");
        spec.threshold = { value: v, unitWord: u }; }
    }
    if (/\b(higher|more|greater|lower|less)\b/.test(q) && spec.shape === "compare") spec.op = /\b(lower|less)\b/.test(q) ? "lt" : "gt";
    spec.status = "OK";
    return spec;
  };

  /* ---------- detective + compute ---------- */
  const fmtU = (x, unit) => unit === "usd" ? G.q2(x) : G.cr(x);
  G.fmtU = fmtU;
  const label = months => !months ? "all data" : months.length === 1 ? G.monthLabel(months[0]) : `${G.monthLabel(months[0])} – ${G.monthLabel(months[months.length - 1])}`;
  G.label = label;
  function predOf(spec, d, extra) {
    return r => (!spec.states.length || spec.states.includes(r.state)) && (!spec.tax || r.tax === spec.tax) && (!spec.source || r.source === spec.source) && (!extra || extra(r));
  }
  function zoneBounds(d, months, measure, zone, basePred, toUsd) {
    // reference Q04 rule: single-zone states count in lo+hi; contradictory-zone states only in hi
    const codes = [...new Set(d.recs.map(r => r.state).concat(Object.values(d.conflicts).flatMap(v => v.map(x => x.state))))].sort();
    let lo = 0n, hi = 0n; const info = { certain: 0, ambiguous: 0, unconvertible: 0, conflicting_record_ids_in_window: 0 }; const contradictory = [], parts = [];
    for (const s of codes) {
      const zs = d.zmap[s] || new Set();
      if (!zs.has(zone)) continue;
      const b = G.bounds(d, months, measure, r => r.state === s && basePred(r), toUsd);
      for (const k in info) info[k] += b.info[k];
      if (zs.size === 1) { lo += b.lo; hi += b.hi; parts.push({ s, b }); }
      else { hi += b.hi; contradictory.push({ state: s, zones: [...zs].sort(), b }); }
    }
    return { lo, hi, info, contradictory, parts };
  }
  function measureWord(m) { return { gross: "Gross collection", net: "Net collection", refund: "Refunds" }[m]; }
  const unitWord = u => u === "usd" ? "USD" : "INR crore";

  G.run = function (spec, d) {
    const out = { spec, status: null, answer: null, unit: unitWord(spec.unit), steps: [], warnings: [], checks: [], chart: null, evidence: null, trail: {} };
    const months = spec.months || d.allMonths, toUsd = spec.unit === "usd";
    const covered = new Set(d.certainMonths), cov0 = G.monthLabel(d.certainMonths[0]), cov1 = G.monthLabel(d.certainMonths[d.certainMonths.length - 1]);
    out.trail.analyzer = `${measureWord(spec.measure)} · ${label(spec.months)}${spec.states.length ? " · " + spec.states.join(", ") : ""}${spec.zone ? " · " + spec.zone + " zone" : ""}${spec.tax ? " · " + spec.tax : ""}${spec.source ? " · " + G.SOURCES[spec.source] : ""} · ${spec.shape}`;
    const refuse = (status, reason, fix, extra = {}) => Object.assign(out, { status, reason, fix }, extra);

    // coverage (Q10 style for YoY)
    if (spec.shape === "yoy") {
      const prior = months.map(m => `${+m.slice(0, 4) - 1}${m.slice(4)}`);
      const have = prior.filter(m => covered.has(m));
      out.trail.detective = `prior-year months present: ${have.length}/${prior.length}`;
      if (have.length < prior.length) return refuse("CANNOT_DETERMINE", `Year-on-year growth needs ${label(prior)} as a baseline, but collections only cover ${cov0} to ${cov1}. There is no prior-year data, so any growth figure would be invented.`, "Ask for the current period alone, or compare two periods inside the data.", { months_present_in_data: d.allMonths });
    }
    for (const p of spec.periods) {
      if (!p) continue;   // "all data": every record, no coverage question
      const P = p, outside = P.filter(m => !covered.has(m));
      if (outside.length) { out.trail.detective = `${outside.length} month(s) outside coverage`; return refuse("CANNOT_DETERMINE", `${label(P)} ${outside.length === P.length ? "is" : "is partly"} outside the data: collections cover ${cov0} to ${cov1}. Reporting a total would silently treat missing months as zero.`, "Ask about months inside the data."); }
    }
    for (const s of spec.states) if (!d.zmap[s] && !d.recs.some(r => r.state === s)) return refuse("CANNOT_DETERMINE", `No state “${s}” in the data.`, "Pick a state from states.csv.");

    const pred = predOf(spec, d);
    const one = (P, measure = spec.measure) => spec.zone ? zoneBounds(d, P, measure, spec.zone, pred, toUsd) : G.bounds(d, P, measure, pred, toUsd);
    const missingIn = P => d.missing.filter(r => pred(r) && r.months.some(m => P.includes(m)) && (!spec.zone || (d.zmap[r.state] || new Set()).has(spec.zone)));

    const common = (b, P) => {
      out.trail.detective = `${b.info.certain} certain · ${b.info.ambiguous} ambiguous date · ${b.info.conflicting_record_ids_in_window} conflicting ID · ${b.info.unconvertible} no FX`;
      const miss = missingIn(P);
      if (miss.length) out.warnings.push(`${miss.length} record(s) in this window have a blank amount (${miss.map(r => r.id).join(", ")}) and are excluded — the true total is higher by their unknown value.`);
      const totalRows = b.info.certain + b.info.ambiguous + miss.length;
      if (totalRows && miss.length / totalRows > 0.10) return `${miss.length} of ${totalRows} records (${Math.round(miss.length / totalRows * 100)}%) have no amount — above the 10% limit.`;
      if (b.info.ambiguous) out.warnings.push(`${b.info.ambiguous} legacy record(s) have dates like 05/06/2026 that read as either DD/MM or MM/DD; their format is undocumented, and at least one reading falls outside ${label(P)}. They count only toward the upper bound.`);
      if (b.info.conflicting_record_ids_in_window) out.warnings.push(`${b.info.conflicting_record_ids_in_window} record ID(s) were exported twice with different amounts (${b.rows ? b.rows.conflict.join(", ") : "conflicts"}). Neither version can be trusted, so only the larger one is added, and only to the upper bound.`);
      if (b.contradictory?.length) out.warnings.push(`states.csv lists ${b.contradictory.map(c => `${c.state} in ${c.zones.join(" and ")}`).join("; ")} — a contradiction. ${b.contradictory.map(c => c.state).join(", ")} counts only toward the upper bound of each candidate zone.`);
      return null;
    };
    const fxLine = P => { const r = P.filter(m => d.fx[m]).map(m => `${G.monthLabel(m)} ${d.fx[m].s}`); return r.length ? `USD↔INR at month-average rates (${r.join(", ")}).` : ""; };

    if (spec.shape === "reconcile") {
      const res = { confirmed_mismatch: [], not_contradicted: [] };
      for (const M of spec.periods.map(p => p || d.allMonths).flat()) {
        for (const r of d.T.monthly_summary) {
          if (r.month !== M) continue; const s = r.state_code; if (spec.states.length && !spec.states.includes(s)) continue;
          const v = toUnits(r.net_revenue_inr_crore);
          const b = G.bounds(d, [M], "net", x => x.state === s);
          // compare in crore with 0.01 tolerance, using exact units
          const vU = v * 10n ** 7n, tol = 10n ** 5n * S16; // 0.01 crore
          const entry = { month: M, state: s, summary: r.net_revenue_inr_crore, computed_range: [G.cr(b.lo), G.cr(b.hi)], lo: b.lo, hi: b.hi, v: vU };
          ((vU < b.lo - tol || vU > b.hi + tol) ? res.confirmed_mismatch : res.not_contradicted).push(entry);
        }
      }
      out.status = "ANSWERED"; out.answer = res; out.unit = "INR crore";
      out.trail.detective = `${res.confirmed_mismatch.length + res.not_contradicted.length} summary lines vs system of record`;
      out.headline = res.confirmed_mismatch.length ? `${res.confirmed_mismatch.map(x => x.state).join(", ")} ${res.confirmed_mismatch.length > 1 ? "contradict" : "contradicts"} collections.csv` : "No summary figure is provably wrong";
      out.steps = [`collections.csv is the system of record; monthly_summary.csv is a manual export (data dictionary).`,
        `For each state, computed the range of net collection the ledger allows (certain records → both bounds; ambiguous legacy dates and conflicting re-exports → upper bound only).`,
        `A summary figure is flagged only if it lies OUTSIDE that range (±0.01 crore). Inside the range means “not contradicted”, which is weaker than “confirmed”.`,
        ...res.confirmed_mismatch.map(x => `${x.state} ${G.monthLabel(x.month)}: summary ${x.summary} vs ledger ${x.computed_range[0]}–${x.computed_range[1]} → mismatch`)];
      out.chart = { type: "reconcile", rows: [...res.confirmed_mismatch, ...res.not_contradicted].sort((a, b) => a.state.localeCompare(b.state)) };
      out.check = [res.confirmed_mismatch.map(x => x.state + "@" + x.month).join(","), res.not_contradicted.length];
      return out;
    }

    if (spec.shape === "breakdown" || spec.shape === "top") {
      const P = months, g = spec.groupBy, monthList = spec.months || d.certainMonths;
      let items = [];
      if (g === "state") {
        const states = [...new Set(d.recs.map(r => r.state))].sort().filter(s => !spec.states.length || spec.states.includes(s));
        for (const s of states) { if (spec.zone && !(d.zmap[s] || new Set()).has(spec.zone)) continue; const b = G.bounds(d, P, spec.measure, r => r.state === s && pred(r), toUsd); items.push({ key: s, label: d.stateName[s] ? `${d.stateName[s]} (${s})` : `${s} — not in states.csv`, lo: b.lo, hi: b.hi, info: b.info }); }
      } else if (g === "zone") {
        for (const z of G.ZONES) { const b = zoneBounds(d, P, spec.measure, z, pred, toUsd); items.push({ key: z, label: z, lo: b.lo, hi: b.hi, info: b.info, contradictory: b.contradictory }); }
        const codes = [...new Set(d.recs.map(r => r.state).concat(Object.values(d.conflicts).flatMap(v => v.map(x => x.state))))];
        const un = codes.filter(s => !d.zmap[s]); let ulo = 0n, uhi = 0n;
        for (const s of un) { const b = G.bounds(d, P, spec.measure, r => r.state === s && pred(r), toUsd); ulo += b.lo; uhi += b.hi; }
        out.unallocated = { states: un, lo: ulo, hi: uhi };
        if (un.length && uhi > 0n) out.warnings.push(`${un.join(", ")} appear in collections.csv but not in states.csv, so they have no zone. Reported separately as unallocated: ${fmtU(ulo, spec.unit)}–${fmtU(uhi, spec.unit)} ${unitWord(spec.unit)}.`);
        const contra = items.flatMap(i => i.contradictory || []).filter((c, i, a) => a.findIndex(x => x.state === c.state) === i);
        if (contra.length) out.warnings.push(`states.csv lists ${contra.map(c => `${c.state} in both ${c.zones.join(" and ")}`).join("; ")} — a contradiction. That state counts only toward the upper bound of each candidate zone, never the lower.`);
        out.contradictoryStates = contra.map(c => ({ state: c.state, zones: c.zones, range: [fmtU(c.b.lo, spec.unit), fmtU(c.b.hi, spec.unit)] }));
      } else if (g === "month") {
        for (const m of monthList) { const b = G.bounds(d, [m], spec.measure, pred, toUsd); items.push({ key: m, label: G.monthLabel(m), lo: b.lo, hi: b.hi, info: b.info, nofx: b.info.unconvertible }); }
      } else if (g === "tax") {
        for (const t of G.TAXES) { const b = G.bounds(d, P, spec.measure, r => r.tax === t && pred(r), toUsd); items.push({ key: t, label: t, lo: b.lo, hi: b.hi, info: b.info }); }
      } else if (g === "source") {
        for (const s of Object.keys(G.SOURCES)) { const b = G.bounds(d, P, spec.measure, r => r.source === s && pred(r), toUsd); items.push({ key: s, label: G.SOURCES[s], lo: b.lo, hi: b.hi, info: b.info }); }
      }
      const unconv = items.reduce((a, i) => a + i.info.unconvertible, 0);
      const amb = items.reduce((a, i) => a + i.info.ambiguous, 0), conf = items.reduce((a, i) => a + i.info.conflicting_record_ids_in_window, 0);
      out.trail.detective = `${items.length} groups · ${amb} ambiguous-date rows · ${conf} conflicting IDs${unconv ? ` · ${unconv} without FX` : ""}`;
      if (amb) out.warnings.push(`${amb} legacy record(s) with undocumented dates could belong to a different month, so affected groups are shown as ranges.`);
      if (conf) out.warnings.push(`Conflicting re-exports (same record ID, different amounts) add only to upper bounds.`);
      const missAll = missingIn(P); if (missAll.length) out.warnings.push(`${missAll.length} record(s) with blank amounts excluded (${missAll.map(r => r.id).join(", ")}).`);
      if (unconv) {
        const bad = items.filter(i => i.info.unconvertible).map(i => i.label);
        out.warnings.push(`${bad.join(", ")}: ${unconv} USD record(s) have no exchange rate (fx_rates.csv ends ${G.monthLabel(Object.keys(d.fx).sort().pop())}). Those groups are incomplete and marked “cannot determine”.`);
        items.forEach(i => (i.incomplete = i.info.unconvertible > 0));
      }
      const mid = i => i.lo + i.hi;
      if (g === "month") { /* keep chronological */ } else items.sort((a, b) => (mid(b) > mid(a) ? 1 : mid(b) < mid(a) ? -1 : a.key.localeCompare(b.key)));
      out.items = items.map(i => ({ ...i, range: [fmtU(i.lo, spec.unit), fmtU(i.hi, spec.unit)], exact: i.lo === i.hi }));
      out.unitWord = unitWord(spec.unit);
      if (spec.shape === "top") {
        let rank = [...items]; if (spec.topDir === "asc") rank.reverse();
        const topk = rank.slice(0, spec.topN), rest = rank.slice(spec.topN);
        const determinate = spec.topDir === "desc"
          ? topk.reduce((a, i) => (i.lo < a ? i.lo : a), topk[0].lo) > rest.reduce((a, i) => (i.hi > a ? i.hi : a), 0n)
          : topk.reduce((a, i) => (i.hi > a ? i.hi : a), topk[0].hi) < rest.reduce((a, i) => (i.lo < a ? i.lo : a), rest[0]?.lo ?? 10n ** 40n);
        out.status = determinate && !topk.some(i => i.incomplete) ? "ANSWERED" : "CANNOT_DETERMINE_RANKING";
        out.answer = { [`top${spec.topN}_by_midpoint`]: topk.map(i => i.key), ranking_is_determinate: determinate, ranges: Object.fromEntries(rank.map(i => [i.key, [fmtU(i.lo, spec.unit), fmtU(i.hi, spec.unit)]])) };
        out.headline = determinate ? `${spec.topDir === "desc" ? "Top" : "Bottom"} ${spec.topN}: ${topk.map(i => i.label).join(", ")}` : `The ${spec.topDir === "desc" ? "top" : "bottom"} ${spec.topN} can’t be pinned down — the ranges overlap`;
        out.steps = [`Computed a ${measureWord(spec.measure).toLowerCase()} range for every ${g} in ${label(spec.months)} (${unitWord(spec.unit)}).`,
          spec.measure === "net" ? "Refunds are subtracted in the month of the ORIGINAL collection, not the refund date (data dictionary)." : null,
          `Ranked by range midpoint: ${rank.slice(0, Math.min(rank.length, spec.topN + 2)).map(i => `${i.key} ${fmtU(i.lo, spec.unit)}–${fmtU(i.hi, spec.unit)}`).join(" · ")}.`,
          determinate ? `The weakest of the top ${spec.topN} (lower bound ${fmtU(topk.reduce((a, i) => (i.lo < a ? i.lo : a), topk[0].lo), spec.unit)}) still beats the best of the rest (upper bound ${fmtU(rest.reduce((a, i) => (i.hi > a ? i.hi : a), 0n), spec.unit)}), so the ranking holds under every possible reading.`
            : `The ranking is claimed only if the lowest top-${spec.topN} lower bound beats the highest upper bound of the rest. Here the ranges overlap, so the order could change depending on how the ambiguous rows are read.`].filter(Boolean);
        out.chart = { type: "ranges", items: out.items, highlight: topk.map(i => i.key), determinate };
        out.check = rank.flatMap(i => [fmtU(i.lo, spec.unit), fmtU(i.hi, spec.unit)]);
        return out;
      }
      const allExact = items.every(i => i.lo === i.hi);
      out.status = unconv ? "ANSWERED_RANGE" : allExact ? "ANSWERED" : "ANSWERED_RANGE";
      out.answer = Object.fromEntries(out.items.map(i => [i.key, i.incomplete ? null : i.exact ? i.range[0] : i.range]));
      out.headline = `${measureWord(spec.measure)} by ${g}, ${label(spec.months)}`;
      out.steps = out.items.map(i => `${i.label}: ${i.incomplete ? "cannot determine (no FX rate)" : i.exact ? i.range[0] : i.range.join(" – ")} ${unitWord(spec.unit)}${i.exact || i.incomplete ? "" : " (range)"}`);
      if (out.unallocated?.states.length) out.steps.push(`Unallocated (${out.unallocated.states.join(", ")}): ${fmtU(out.unallocated.lo, spec.unit)} – ${fmtU(out.unallocated.hi, spec.unit)}`);
      out.chart = { type: g === "month" ? "months" : "ranges", items: out.items };
      out.check = out.items.flatMap(i => [fmtU(i.lo, spec.unit), fmtU(i.hi, spec.unit)]);
      return out;
    }

    if (spec.shape === "count") {
      const b = one(months); const stop = common(b, months);
      out.status = b.info.ambiguous || b.info.conflicting_record_ids_in_window ? "ANSWERED_RANGE" : "ANSWERED";
      const lo = b.info.certain, hi = b.info.certain + b.info.ambiguous + b.info.conflicting_record_ids_in_window;
      out.answer = lo === hi ? String(lo) : [String(lo), String(hi)]; out.unit = "records";
      out.headline = lo === hi ? `${lo} records` : `Between ${lo} and ${hi} records`;
      out.steps = [`Unique records after dropping exact re-exports: ${b.info.certain} certainly in ${label(months)}.`, b.info.ambiguous ? `${b.info.ambiguous} more might be (ambiguous legacy dates).` : null, b.info.conflicting_record_ids_in_window ? `${b.info.conflicting_record_ids_in_window} conflicting record ID(s) counted once, upper bound only.` : null].filter(Boolean);
      out.check = [lo, hi]; out.chart = null; return out;
    }

    // total / threshold / compare / yoy (yoy already refused when no baseline)
    const Ps = spec.periods.map(p => p || d.allMonths);
    const bs = Ps.map(P => one(P));
    for (let i = 0; i < bs.length; i++) {
      const st = common(bs[i], Ps[i]);
      if (st) return refuse("CANNOT_DETERMINE", st, "Fill in the blank amounts and reload the data.");
      if (bs[i].info.unconvertible) {
        const inrOnly = G.bounds(d, Ps[i], spec.measure, pred, false);
        return refuse("CANNOT_DETERMINE", `${bs[i].info.unconvertible} USD record(s) in ${label(spec.periods[i])} can’t be converted: fx_rates.csv only covers ${G.monthLabel(Object.keys(d.fx).sort()[0])} to ${G.monthLabel(Object.keys(d.fx).sort().pop())}. Any total would need an exchange rate that doesn’t exist in the data, so it would be a guess.`,
          "Add that month’s USD→INR rate to fx_rates.csv.", { lowerBoundInrOnly: G.cr(inrOnly.lo), info: bs[i].info });
      }
    }
    const b = bs[0], P = Ps[0];
    out.info = b.info; out.lo = b.lo; out.hi = b.hi; out.rows = b.rows;
    const rangeTxt = x => x.lo === x.hi ? fmtU(x.lo, spec.unit) : `${fmtU(x.lo, spec.unit)} – ${fmtU(x.hi, spec.unit)}`;
    const certainSum = rows => rows.reduce((a, r) => a, 0n);
    out.steps = [
      `Filter: ${measureWord(spec.measure).toLowerCase()} for ${label(P)}${spec.states.length ? `, state ${spec.states.join("/")}` : ""}${spec.zone ? `, ${spec.zone} zone` : ""}${spec.tax ? `, ${spec.tax}` : ""}${spec.source ? `, source ${spec.source}` : ""}.`,
      `Dropped ${d.exactDupes.reduce((a, x) => a + x.copies, 0)} exact re-export row(s) across the file; read each source’s documented date format (gst_portal DD/MM, state_treasury MM/DD).`,
      `${b.info.certain} record(s) fall in the window under every possible date reading → counted in both bounds.`,
      b.info.ambiguous ? `${b.info.ambiguous} legacy record(s) might fall in the window → added to the upper bound only.` : `No legacy-date ambiguity touches this window.`,
      b.info.conflicting_record_ids_in_window ? `${b.info.conflicting_record_ids_in_window} conflicting re-export(s) → larger version added to the upper bound only.` : null,
      spec.measure === "net" ? "Refunds subtracted in the month of the original collection (data dictionary)." : spec.measure === "refund" ? "Refunds summed in the month of the original collection." : "Gross = sum of amounts; refunds not deducted.",
      spec.unit === "usd" ? `INR amounts divided by that month’s USD→INR rate; USD amounts kept as-is. ${fxLine(P)}` : (b.rows?.certain || []).some(r => r.ccy === "USD") ? `USD records converted to INR at the collection month’s rate. ${fxLine(P)}` : null,
      spec.unit === "crore" ? "Units: INR crore (1 crore = 10,000,000), rounded half-up to 2 decimals." : "Rounded half-up to 2 decimals.",
      `Result: ${rangeTxt(b)} ${unitWord(spec.unit)}${b.lo === b.hi ? " — exact, because nothing in the window is ambiguous." : " — a range, because the data cannot place every record with certainty."}`,
    ].filter(Boolean);
    out.zoneContradictions = b.contradictory;

    if (spec.shape === "compare" || spec.shape === "yoy") {
      const [a, c] = bs, dlo = a.lo - c.hi, dhi = a.hi - c.lo;
      out.status = "ANSWERED_RANGE"; out.answer = { [label(Ps[0])]: [fmtU(a.lo, spec.unit), fmtU(a.hi, spec.unit)], [label(Ps[1])]: [fmtU(c.lo, spec.unit), fmtU(c.hi, spec.unit)], difference: [fmtU(dlo, spec.unit), fmtU(dhi, spec.unit)] };
      if (dlo === dhi) out.status = "ANSWERED";
      let verdict = null;
      if (spec.op) { const yes = spec.op === "gt" ? dlo > 0n : dhi < 0n, no = spec.op === "gt" ? dhi <= 0n : dlo >= 0n; verdict = yes ? "Yes" : no ? "No" : null; if (!verdict) out.status = "CANNOT_DETERMINE"; }
      out.verdict = verdict;
      out.headline = spec.op ? (verdict ? `${verdict} — ${label(Ps[0])} ${rangeTxt(a)} vs ${label(Ps[1])} ${rangeTxt(c)}` : `Can’t tell — the two ranges overlap`) : `${label(Ps[0])} vs ${label(Ps[1])}: difference ${dlo === dhi ? fmtU(dlo, spec.unit) : fmtU(dlo, spec.unit) + " to " + fmtU(dhi, spec.unit)}`;
      if (!verdict && spec.op) out.reason = `${label(Ps[0])} is ${rangeTxt(a)} and ${label(Ps[1])} is ${rangeTxt(c)}. The ranges overlap, so the comparison depends on how the ambiguous rows are read.`;
      out.steps.push(`${label(Ps[1])}: ${rangeTxt(c)} ${unitWord(spec.unit)}.`, `Difference range = [low A − high B, high A − low B] = [${fmtU(dlo, spec.unit)}, ${fmtU(dhi, spec.unit)}].`);
      out.chart = { type: "ranges", items: [{ key: "A", label: label(Ps[0]), lo: a.lo, hi: a.hi }, { key: "B", label: label(Ps[1]), lo: c.lo, hi: c.hi }] };
      out.check = [fmtU(a.lo, spec.unit), fmtU(a.hi, spec.unit), fmtU(c.lo, spec.unit), fmtU(c.hi, spec.unit)];
      return out;
    }
    if (spec.shape === "threshold") {
      const t = spec.threshold; const mult = { crore: CRORE_U, cr: CRORE_U, lakh: 10n ** 5n * S16, million: 10n ** 6n * S16, bn: 10n ** 9n * S16, billion: 10n ** 9n * S16, "": S16 }[t.unitWord] ?? S16;
      const T = toUnits(String(t.value)) * mult / S16;
      const yes = spec.op === "gt" ? b.lo > T : b.hi < T, no = spec.op === "gt" ? b.hi <= T : b.lo >= T;
      out.verdict = yes ? "Yes" : no ? "No" : null;
      out.status = out.verdict ? (b.lo === b.hi ? "ANSWERED" : "ANSWERED_RANGE") : "CANNOT_DETERMINE";
      out.answer = { verdict: out.verdict, range: [fmtU(b.lo, spec.unit), fmtU(b.hi, spec.unit)], threshold: fmtU(T, spec.unit) };
      out.headline = out.verdict ? `${out.verdict} — ${rangeTxt(b)} ${unitWord(spec.unit)} vs ${fmtU(T, spec.unit)}` : `Can’t tell — the threshold ${fmtU(T, spec.unit)} sits inside the possible range`;
      if (!out.verdict) out.reason = `The total could be anywhere from ${fmtU(b.lo, spec.unit)} to ${fmtU(b.hi, spec.unit)}, and ${fmtU(T, spec.unit)} is inside that range.`;
      out.steps.push(`Threshold ${fmtU(T, spec.unit)} ${unitWord(spec.unit)}: ${out.verdict === "Yes" ? "the whole range is on the right side" : out.verdict === "No" ? "the whole range is on the wrong side" : "falls inside the range"}.`);
      out.chart = { type: "band", lo: b.lo, hi: b.hi, mark: T, info: b.info }; out.thresholdU = T;
      out.check = [fmtU(b.lo, spec.unit), fmtU(b.hi, spec.unit)];
      return out;
    }
    out.status = b.lo === b.hi ? "ANSWERED" : "ANSWERED_RANGE";
    out.answer = b.lo === b.hi ? fmtU(b.lo, spec.unit) : [fmtU(b.lo, spec.unit), fmtU(b.hi, spec.unit)];
    out.headline = `${measureWord(spec.measure)}${spec.zone ? `, ${spec.zone} zone` : ""}${spec.states.length ? `, ${spec.states.map(s => d.stateName[s] || s).join(" & ")}` : ""}${spec.tax ? `, ${spec.tax}` : ""}${spec.source ? `, ${G.SOURCES[spec.source]}` : ""} · ${label(P)}`;
    out.chart = { type: "band", lo: b.lo, hi: b.hi, info: b.info };
    out.check = [fmtU(b.lo, spec.unit), fmtU(b.hi, spec.unit)];
    return out;
  };

  /* ---------- auditor: independent second implementation ----------
     Re-reads raw CSV rows with its own parsers (regex digit-stripping, own date logic),
     own dedup and conflict handling. Shares no code with load()/bounds(). */
  G.audit = function (spec, T) {
    const rate = {}; T.fx_rates.forEach(r => { if (r.from_ccy + ">" + r.to_ccy === "USD>INR") { const [w, f = ""] = r.rate.trim().split("."); rate[r.month] = BigInt(w) * 100n + BigInt((f + "00").slice(0, 2)); } });
    const units = s => { const neg = s.startsWith("-"); s = s.replace(/^-/, ""); const [i, f = ""] = s.split("."); const v = BigInt(i || "0") * S16 + BigInt((f + "0".repeat(16)).slice(0, 16)); return neg ? -v : v; };
    const amount = (txt, src) => {
      let s = txt.replace(/₹|Rs\.|\$/g, "").trim(); if (!s) return null;
      if (src === "state_treasury") { const k = s.lastIndexOf(","); s = k < 0 ? s.replace(/\./g, "") : s.slice(0, k).replace(/\./g, "") + "." + s.slice(k + 1); }
      else s = s.replace(/,/g, "");
      return units(s);
    };
    const cur = (txt, col) => col.trim().toUpperCase() || (/\$/.test(txt) ? "USD" : /₹|Rs\./.test(txt) ? "INR" : null);
    const mons = (dt, src) => { const [x, y, yr] = dt.split("/").map(Number); const f = (m) => `${yr}-${m < 10 ? "0" + m : m}`;
      if (src === "gst_portal") return [f(y)]; if (src === "state_treasury") return [f(x)];
      if (x > 12) return [f(y)]; if (y > 12) return [f(x)]; return x === y ? [f(x)] : [f(Math.min(x, y)), f(Math.max(x, y))]; };
    const byId = {};
    T.collections.forEach(r => { const k = Object.keys(r).sort().map(c => c + "=" + r[c]).join("|"); (byId[r.record_id] ||= new Set()).add(k); });
    const rowsById = {}; T.collections.forEach(r => (rowsById[r.record_id] ||= []).push(r));
    const ref = {}; T.refunds.forEach(r => (ref[r.record_id] = (ref[r.record_id] || 0n) + units(r.amount)));
    const zones = {}; T.states.forEach(r => (zones[r.state_code] ||= new Set()).add(r.zone));
    const W = new Set(spec.months || [...new Set(T.collections.flatMap(r => byId[r.record_id].size === 1 && amount(r.amount, r.source_system) !== null ? mons(r.collection_date, r.source_system) : []))]);
    const toUsd = spec.unit === "usd";
    const val = (amt, ccy, refund, m) => {
      const rt = rate[m]; if ((ccy === "USD" || toUsd) && rt === undefined) return null;
      let base = spec.measure === "refund" ? refund : spec.measure === "net" ? amt - refund : amt;
      let inr = ccy === "USD" ? base * rt / 100n : base;
      return toUsd ? inr * 100n / rt : inr;
    };
    const keep = (state, tax, src) => (!spec.states.length || spec.states.includes(state)) && (!spec.tax || spec.tax === tax) && (!spec.source || spec.source === src);
    const zoneOK = (state, strict) => { if (!spec.zone) return true; const z = zones[state]; if (!z || !z.has(spec.zone)) return false; return strict ? z.size === 1 : true; };
    let lo = 0n, hi = 0n, unconv = 0;
    for (const id of Object.keys(rowsById)) {
      const versions = [...new Map(rowsById[id].map(r => [Object.keys(r).sort().map(c => c + "=" + r[c]).join("|"), r])).values()];
      if (versions.length > 1) {
        let best = null;
        for (const r of versions) { if (!keep(r.state_code, r.tax_type, r.source_system) || !zoneOK(r.state_code, false)) continue; const a = amount(r.amount, r.source_system); if (a === null) continue;
          for (const m of mons(r.collection_date, r.source_system)) if (W.has(m)) { const v = val(a, cur(r.amount, r.currency), 0n, m); if (v !== null && (best === null || v > best)) best = v; } }
        if (best !== null) hi += best; continue;
      }
      const r = versions[0]; if (!keep(r.state_code, r.tax_type, r.source_system) || !zoneOK(r.state_code, false)) continue;
      const a = amount(r.amount, r.source_system); if (a === null) continue;
      const ms = mons(r.collection_date, r.source_system), inside = ms.filter(m => W.has(m)); if (!inside.length) continue;
      const c = cur(r.amount, r.currency), rf = ref[id] || 0n;
      const vin = inside.map(m => val(a, c, rf, m)); if (vin.includes(null)) { unconv++; continue; }
      const vall = ms.map(m => val(a, c, rf, m));
      const strict = zoneOK(r.state_code, true);
      if (inside.length === ms.length) { if (strict) lo += vall.reduce((p, q) => (q < p ? q : p)); hi += vall.reduce((p, q) => (q > p ? q : p)); }
      else hi += vin.reduce((p, q) => (q > p ? q : p));
    }
    return { lo, hi, unconv };
  };

  /* ---------- orchestrator ---------- */
  G.ask = function (question, d) {
    const t0 = (typeof performance !== "undefined" ? performance.now() : Date.now());
    const spec = G.analyze(question, d);
    if (spec.status !== "OK") return { spec, status: spec.status, reason: spec.reason, fix: spec.fix, steps: [], warnings: [], trail: { analyzer: "stopped here", detective: "—", gate: spec.status }, ms: 0 };
    const out = G.run(spec, d);
    out.trail.gate = out.status;
    const simpleTotal = ["total", "threshold"].includes(spec.shape) && out.lo !== undefined;
    if (simpleTotal && !["CANNOT_DETERMINE", "INVALID_QUESTION"].includes(out.status) || (simpleTotal && out.status === "CANNOT_DETERMINE" && out.lo !== undefined)) {
      const a = G.audit(spec, d.T);
      out.audit = { lo: fmtU(a.lo, spec.unit), hi: fmtU(a.hi, spec.unit), agree: a.lo === out.lo && a.hi === out.hi };
      out.trail.auditor = out.audit.agree ? `independent recount ${out.audit.lo === out.audit.hi ? out.audit.lo : out.audit.lo + "–" + out.audit.hi} ✓` : "MISMATCH";
      if (!out.audit.agree) { out.status = "CANNOT_DETERMINE"; out.reason = `Two independent calculations disagree (main ${fmtU(out.lo, spec.unit)}–${fmtU(out.hi, spec.unit)}, auditor ${out.audit.lo}–${out.audit.hi}). Refusing rather than guessing.`; }
    } else if (out.status && !["CANNOT_DETERMINE", "INVALID_QUESTION"].includes(out.status)) {
      out.audit = { agree: true, note: "group results re-derived from the same exact bounds; each group total is checked against the Python proof" };
      out.trail.auditor = "per-group totals re-derived ✓";
    } else out.trail.auditor = "not needed (no number given)";
    if (out.status !== "CANNOT_DETERMINE" && out.status !== "INVALID_QUESTION") out.python = G.python(spec, out);
    out.trail.verifier = out.python ? "Python proof script generated" : "reason recorded";
    out.ms = Math.round(((typeof performance !== "undefined" ? performance.now() : Date.now()) - t0) * 10) / 10;
    return out;
  };

  /* ---------- Python proof (embeds pda_common.py verbatim) ---------- */
  G.PDA_COMMON = "";  // set by the page (source of pda_common.py)
  G.python = function (spec, out) {
    const P = x => JSON.stringify(x).replace(/\bnull\b/g, "None").replace(/\btrue\b/g, "True").replace(/\bfalse\b/g, "False");
    const SPEC = { measure: spec.measure, unit: spec.unit, periods: spec.periods.map(p => p), states: spec.states, zone: spec.zone, tax: spec.tax, source: spec.source, shape: spec.shape, groupBy: spec.groupBy, topN: spec.topN, topDir: spec.topDir };
    const lib = G.PDA_COMMON.replace(/^"""[\s\S]*?"""\n/, "");
    return `#!/usr/bin/env python3
"""
PROOF SCRIPT — GST Proof Desk
Question : ${spec.question.replace(/"""/g, "'")}
Status   : ${out.status}
Run      : put this file next to the data/ folder (collections.csv, refunds.csv, states.csv,
           fx_rates.csv, monthly_summary.csv) and run  python proof.py   or  python proof.py path/to/data
Needs    : Python 3.8+ only (standard library). The rules below are pda_common.py, verbatim,
           followed by the query for this question.
"""
${lib}
import sys as _sys
DATA = Path(_sys.argv[1]) if len(_sys.argv) > 1 else Path(__file__).resolve().parent / "data"

SPEC = ${P(SPEC)}
ZONES = ["North", "South", "East", "West"]
TAXES = ["CGST", "SGST", "IGST", "CESS"]
SOURCES = ["gst_portal", "state_treasury", "legacy"]
d = load()
ALL = sorted({m for r in d["recs"] for m in r["months"]})
zmap = {}
for r in read("states.csv"): zmap.setdefault(r["state_code"], set()).add(r["zone"])
usd = SPEC["unit"] == "usd"
fmt = (lambda x: q2(x)) if usd else (lambda x: cr(x))

def keep(r):
    return ((not SPEC["states"] or r["state"] in SPEC["states"]) and (not SPEC["tax"] or r["tax"] == SPEC["tax"])
            and (not SPEC["source"] or r["source"] == SPEC["source"]))

def measure_bounds(months, pred):
    m = SPEC["measure"]
    if m == "refund":   # refunds = gross - net, record by record
        lo_g, hi_g, i1 = bounds(d, months, "gross", pred, usd); lo_n, hi_n, i2 = bounds(d, months, "net", pred, usd)
        return lo_g - lo_n, hi_g - hi_n, i1
    return bounds(d, months, m, pred, usd)

def zone_bounds(months, zone, base):
    codes = sorted({r["state"] for r in d["recs"]} | {x["state"] for v in d["conflicts"].values() for x in v})
    lo = hi = Decimal(0); info = {}
    for s in codes:
        zs = zmap.get(s, set())
        if zone not in zs: continue
        a, b, i = measure_bounds(months, lambda r, s=s: r["state"] == s and base(r))
        for k, v in i.items(): info[k] = info.get(k, 0) + v
        if len(zs) == 1: lo += a; hi += b
        else: hi += b
    return lo, hi, info

def total(months):
    if SPEC["zone"]: return zone_bounds(months, SPEC["zone"], keep)
    return measure_bounds(months, keep)

periods = [p or ALL for p in SPEC["periods"]]
shape = SPEC["shape"]
if shape in ("breakdown", "top"):
    M, g, rows = periods[0], SPEC["groupBy"], []
    if g == "state":
        for s in sorted({r["state"] for r in d["recs"]}):
            if SPEC["states"] and s not in SPEC["states"]: continue
            if SPEC["zone"] and SPEC["zone"] not in zmap.get(s, set()): continue
            a, b, i = measure_bounds(M, lambda r, s=s: r["state"] == s and keep(r)); rows.append((s, a, b, i))
    elif g == "zone":
        for z in ZONES:
            a, b, i = zone_bounds(M, z, keep); rows.append((z, a, b, i))
    elif g == "month":
        for m in (SPEC["periods"][0] or sorted({r["months"][0] for r in d["recs"] if len(r["months"]) == 1})):
            a, b, i = measure_bounds([m], keep); rows.append((m, a, b, i))
    elif g == "tax":
        for t in TAXES:
            a, b, i = measure_bounds(M, lambda r, t=t: r["tax"] == t and keep(r)); rows.append((t, a, b, i))
    else:
        for s in SOURCES:
            a, b, i = measure_bounds(M, lambda r, s=s: r["source"] == s and keep(r)); rows.append((s, a, b, i))
    if g != "month": rows.sort(key=lambda t: (-(t[1] + t[2]), t[0]))
    if shape == "top":
        rank = rows[::-1] if SPEC["topDir"] == "asc" else rows
        top, rest = rank[:SPEC["topN"]], rank[SPEC["topN"]:]
        if SPEC["topDir"] == "asc":
            det = max(t[2] for t in top) < min((t[1] for t in rest), default=Decimal(10) ** 40)
        else:
            det = min(t[1] for t in top) > max((t[2] for t in rest), default=0)
        emit("PROOF", "ANSWERED" if det else "CANNOT_DETERMINE_RANKING",
             {"top_by_midpoint": [t[0] for t in top], "ranking_is_determinate": det,
              "ranges": {t[0]: [fmt(t[1]), fmt(t[2])] for t in rank}}, ["ranking claimed only if bounds separate"])
    else:
        emit("PROOF", "ANSWERED_RANGE", {t[0]: [fmt(t[1]), fmt(t[2])] for t in rows}, ["per-group bounds"],
             unit="USD" if usd else "INR crore", no_fx_rows={t[0]: t[3]["unconvertible"] for t in rows if t[3]["unconvertible"]})
elif shape == "reconcile":
    mism, ok = [], []
    for M in periods[0]:
        for r in read("monthly_summary.csv"):
            if r["month"] != M or (SPEC["states"] and r["state_code"] not in SPEC["states"]): continue
            s = r["state_code"]; v = Decimal(r["net_revenue_inr_crore"])
            lo, hi, _ = bounds(d, [M], "net", lambda x, s=s: x["state"] == s)
            lo, hi = lo / CRORE, hi / CRORE
            (mism if (v < lo - Decimal("0.01") or v > hi + Decimal("0.01")) else ok).append(
                {"state": s, "summary": str(v), "computed_range": [q2(lo), q2(hi)]})
    emit("PROOF", "ANSWERED", {"confirmed_mismatch": mism, "not_contradicted": ok}, ["flag only outside computable range"], unit="INR crore")
elif shape == "count":
    lo, hi, info = total(periods[0])
    emit("PROOF", "ANSWERED", [info["certain"], info["certain"] + info["ambiguous"] + info["conflicting_record_ids_in_window"]], ["record count"])
else:
    res = [total(p) for p in periods]
    for (lo, hi, info), p in zip(res, periods):
        if info.get("unconvertible"):
            emit("PROOF", "CANNOT_DETERMINE", None, ["no FX rate for some USD rows"], info=info); _sys.exit(0)
    out = [[fmt(lo), fmt(hi)] for lo, hi, _ in res]
    status = "ANSWERED" if all(a == b for a, b in out) else "ANSWERED_RANGE"
    emit("PROOF", status, out[0][0] if (len(out) == 1 and out[0][0] == out[0][1]) else out,
         ["bounds: certain rows in lo and hi; ambiguous legacy dates and conflicting re-exports in hi only"],
         unit="USD" if usd else "INR crore", info=res[0][2])
`;
  };

  if (typeof module !== "undefined" && module.exports) module.exports = G; else root.G = G;
})(typeof window !== "undefined" ? window : globalThis);
