"""Shared, deterministic cleaning + bounds logic. Rules come ONLY from data_dictionary.md."""
import csv, json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

DATA = Path(__file__).parent / "data"
CRORE = Decimal(10) ** 7
FY_Q = {1: ["04", "05", "06"], 2: ["07", "08", "09"], 3: ["10", "11", "12"], 4: ["01", "02", "03"]}


def read(name):
    with open(DATA / name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fy_quarter_months(fy_start_year, q):
    """FY starts 1 April. FY2026-27 Q1 -> 2026-04..06 ; Q4 -> 2027-01..03."""
    if q not in FY_Q: raise ValueError("fiscal quarter must be 1..4")
    return [f"{fy_start_year + (1 if q == 4 else 0)}-{m}" for m in FY_Q[q]]


def parse_amount(text, ccy, source):
    t = (text or "").strip()
    if not t: return None, None
    sym = None
    for s, c in (("₹", "INR"), ("Rs.", "INR"), ("$", "USD")):
        if s in t: sym, t = c, t.replace(s, "")
    ccy = (ccy or "").strip().upper() or sym
    if sym and ccy != sym: raise ValueError("currency/symbol conflict")
    t = t.strip()
    t = t.replace(".", "").replace(",", ".") if source == "state_treasury" else t.replace(",", "")
    return Decimal(t), ccy


def possible_months(text, source):
    a, b, y = text.split("/")
    a, b = int(a), int(b)
    if source == "gst_portal": opts = [(y, b)]                  # DD/MM/YYYY
    elif source == "state_treasury": opts = [(y, a)]            # MM/DD/YYYY
    else:                                                       # legacy: undocumented
        opts = [(y, b)] if a > 12 else [(y, a)] if b > 12 else [(y, a), (y, b)]
    return sorted({f"{yy}-{int(mm):02d}" for yy, mm in opts})


def load():
    fx = {r["month"]: Decimal(r["rate"]) for r in read("fx_rates.csv")
          if r["from_ccy"] == "USD" and r["to_ccy"] == "INR"}
    groups = {}
    for r in read("collections.csv"): groups.setdefault(r["record_id"], []).append(r)
    recs, conflicts, missing = [], {}, []
    for rid, rows in groups.items():
        uniq = {tuple(sorted(x.items())): x for x in rows}.values()   # drops exact re-exports
        parsed = []
        for x in uniq:
            amt, ccy = parse_amount(x["amount"], x["currency"], x["source_system"])
            parsed.append(dict(id=rid, state=x["state_code"], tax=x["tax_type"], source=x["source_system"],
                               amt=amt, ccy=ccy, months=possible_months(x["collection_date"], x["source_system"])))
        if len(parsed) > 1: conflicts[rid] = parsed; continue
        if parsed[0]["amt"] is None: missing.append(parsed[0]); continue
        recs.append(parsed[0])
    refunds = {}
    for r in read("refunds.csv"):
        refunds.setdefault(r["record_id"], []).append(Decimal(r["amount"]))
    ids = {r["id"] for r in recs}
    orphan_refunds = [k for k in refunds if k not in ids and k not in conflicts]
    for r in recs: r["refund"] = sum(refunds.get(r["id"], []), Decimal(0))
    return dict(fx=fx, recs=recs, conflicts=conflicts, missing=missing, orphan_refunds=orphan_refunds)


def value(rec, month, measure, fx, to_usd=False):
    """Value of rec if it belongs to `month`. None => no FX rate available."""
    rate = fx.get(month)
    if rec["ccy"] == "USD" and rate is None: return None
    if to_usd and rate is None: return None
    base = rec["amt"] - (rec["refund"] if measure == "net" else 0)
    inr = base * (rate if rec["ccy"] == "USD" else 1)
    return inr / rate if to_usd else inr


def bounds(d, months, measure="gross", pred=lambda r: True, to_usd=False):
    """(lo, hi, info). lo = certain records only; hi adds every record that *might* fall in window,
    plus the larger version of unresolved conflicting re-exports."""
    lo = hi = Decimal(0); info = dict(certain=0, ambiguous=0, unconvertible=0)
    for r in d["recs"]:
        if not pred(r): continue
        ins = [m for m in r["months"] if m in months]
        if not ins: continue
        vals = [value(r, m, measure, d["fx"], to_usd) for m in r["months"]]
        if any(v is None for v in [value(r, m, measure, d["fx"], to_usd) for m in ins]):
            info["unconvertible"] += 1; continue
        if len(ins) == len(r["months"]):
            lo += min(vals); hi += max(vals); info["certain"] += 1
        else:
            hi += max(value(r, m, measure, d["fx"], to_usd) for m in ins); info["ambiguous"] += 1
    info["conflicting_record_ids_in_window"] = 0
    for rid, versions in d["conflicts"].items():
        cand = [(v, m) for v in versions for m in v["months"] if m in months and pred(v)]
        if cand:
            vals = [value({**v, "refund": Decimal(0)}, m, measure, d["fx"], to_usd) for v, m in cand]
            vals = [x for x in vals if x is not None]
            if vals: hi += max(vals); info["conflicting_record_ids_in_window"] += 1
    return lo, hi, info


def cr(x): return str((x / CRORE).quantize(Decimal("0.01"), ROUND_HALF_UP))
def q2(x): return str(x.quantize(Decimal("0.01"), ROUND_HALF_UP))


def emit(qid, status, answer, assumptions, **extra):
    print(json.dumps(dict(question=qid, status=status, answer=answer, assumptions=assumptions, **extra),
                     sort_keys=True, indent=1, default=str))
