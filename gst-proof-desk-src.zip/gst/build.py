import json
from pathlib import Path
d = Path(__file__).parent
files = {f.name: f.read_text(encoding="utf-8") for f in sorted((d / "data").glob("*.csv"))}
consts = ("const DATA_FILES = " + json.dumps(files, ensure_ascii=False) + ";\n"
          "const DICT_SRC = " + json.dumps((d / "data_dictionary.md").read_text(encoding="utf-8"), ensure_ascii=False) + ";\n"
          "const PDA_COMMON_SRC = " + json.dumps((d / "pda_common.py").read_text(encoding="utf-8"), ensure_ascii=False) + ";\n")
html = (d / "shell.html").read_text() + (d / "body.html").read_text() + \
    "".join(f"<script>\n{x}\n</script>\n" for x in [consts, (d / "engine.js").read_text(), (d / "app.js").read_text(), (d / "core.js").read_text(), (d / "chat.js").read_text()])
(d / "dist").mkdir(exist_ok=True)
(d / "dist" / "gst-proof-desk.html").write_text(html, encoding="utf-8")
print(len(html) // 1024, "KB")
