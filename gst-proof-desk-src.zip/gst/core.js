/* Agent core: the tools Claude may call, the instructions it gets, and the
   number-grounding check. Pure functions over the verified engine (G). */
(function (root) {
  "use strict";
  const A = {};
  const HARD = [/relative/i, /why something happened/i, /no Q\d|exactly four quarters/i, /not a valid fiscal year/i, /doesn’t exist/i, /ambiguous/i, /which year/i, /too many periods|can’t pair/i];

  /** Tool 1 — deterministic screen of the user's exact words. */
  A.screen = function (question, d) {
    const s = G.analyze(String(question || ""), d);
    if (s.status === "OK") return { verdict: "ok", reading: readSpec(s), note: "The rule engine can parse this as written. You may pass it to query_ledger unchanged or in canonical form." };
    const absent = /capita|population|gdp|employee|staff|headcount|profit|expense|margin|salary|inflation|budget|forecast|2025-0[1-9]|tax rate/i.test(question);
    const hard = absent || HARD.some(re => re.test(s.reason || ""));
    return { verdict: hard ? "hard_stop" : "unrecognised_words", status: s.status, reason: s.reason, fix: s.fix || null,
      note: hard ? "HARD STOP: do not rewrite this away. Tell the user it can’t be answered as asked, why, and what would fix it."
                 : "Some words aren’t in the engine’s vocabulary. Rewrite ONLY if they are synonyms of supported concepts (collection, refunds, net, state, zone, tax type, source, month, FY quarter). If they name something the data lacks (population, employees, profit, GDP…), report that it can’t be determined." };
  };
  function readSpec(s) {
    return { measure: s.measure, unit: s.unit, shape: s.shape, group_by: s.groupBy, periods: s.periods.map(p => p ? G.label(p) : "all data"),
      states: s.states, zone: s.zone, tax: s.tax, source: s.source };
  }

  /** Tool 2 — run a canonical question through the verified pipeline. Returns small plain data. */
  A.query = function (canonical, d) {
    const o = G.ask(String(canonical || ""), d);
    const out = { query: String(canonical), status: o.status };
    if (o.status === "CANNOT_DETERMINE" || o.status === "INVALID_QUESTION") {
      Object.assign(out, { reason: o.reason, fix: o.fix || null });
      if (o.lowerBoundInrOnly) out.inr_only_lower_bound_crore = o.lowerBoundInrOnly;
      return { summary: out, full: o };
    }
    out.unit = o.unit === "USD" ? "USD" : o.unit === "records" ? "records" : "INR crore";
    out.headline = o.headline;
    if (o.verdict !== undefined) out.verdict = o.verdict;
    if (o.items) out.groups = o.items.map(i => ({ group: i.label, value: i.incomplete ? "cannot determine (no FX)" : i.exact ? i.range[0] : i.range }));
    else out.answer = o.answer;
    if (o.reason) out.why_not_plain = o.reason;
    out.method = o.steps.slice(0, 9);
    out.traps = o.warnings.slice(0, 6);
    out.verified = { independent_recount: o.audit ? (o.audit.agree ? "agrees" : "DISAGREES") : "n/a", python_proof: o.python ? "generated" : "none" };
    return { summary: out, full: o };
  };

  /** The data card Claude reads (kept short: it is re-read every round). */
  A.dataCard = function (d) {
    const states = Object.entries(d.stateName).map(([c, n]) => `${n} (${c}): ${[...d.zmap[c]].join("/")}`).join("; ");
    return `DATA (synthetic India GST ledger, data.gov.in-style schema):
- collections.csv (system of record): ${d.recs.length} usable records, months ${G.monthLabel(d.certainMonths[0])}–${G.monthLabel(d.certainMonths[d.certainMonths.length - 1])}. Tax types CGST, SGST, IGST, CESS. Sources: gst_portal, state_treasury, legacy.
- States/zones: ${states}. TG appears in collections but not in states.csv (unallocated). KA is listed in two zones (contradiction).
- refunds.csv (booked to the month of the original collection), fx_rates.csv (USD→INR, ${Object.keys(d.fx).sort().map(G.monthLabel).join(", ")} only), monthly_summary.csv (manual export, net ₹ crore per state per month).
- Fiscal year starts 1 April: FY2026-27 Q1 = Apr–Jun 2026; FY2025-26 Q4 = Jan–Mar 2026. Units: INR crore unless USD asked.
- Not in the data: population, GDP, employees, profit/expenses, anything before Jan 2026, exchange rates after Jun 2026.`;
  };

  A.RULES = `You are the analyst agent of "GST Proof Desk". You answer questions about the GST ledger below. Numbers must be PROVEN, never estimated.

HOW TO WORK
1. Call screen_question with the user's exact words (for a follow-up, resolve it into a full standalone question first, e.g. "and May?" → "Gross collection in May 2026", then screen that).
2. If screen_question returns hard_stop: do NOT call query_ledger with a rewrite that removes the problem. Explain plainly why it can't be answered and what would make it answerable.
3. Otherwise call query_ledger with ONE canonical question per figure you need. Canonical grammar (use these shapes):
   "Gross collection in April 2026" · "Net collection in Kerala in FY2025-26 Q4" · "Total refunds in January 2026"
   "Gross collection by state|zone|month|tax type|source in FY2026-27 Q1" · "Top 3 states by net collection in March 2026" · "Lowest zone by gross collection in May 2026"
   "IGST collection in USD in FY2026-27 Q1" · "Gross collection for GST portal in April 2026" · "Was gross collection higher in May 2026 than April 2026?"
   "Did gross collection exceed 1000 crore in June 2026?" · "Which state figures in monthly_summary for 2026-03 contradict collections?" · "How many records in January 2026?"
4. Read the status: ANSWERED = exact figure. ANSWERED_RANGE = only a range is provable — give the range and say why (ambiguous legacy dates, conflicting re-exports); never quote a midpoint as the answer. CANNOT_DETERMINE_RANKING = the order isn't provable; say so. CANNOT_DETERMINE / INVALID_QUESTION = say you can't determine it, give the reason and the fix.
5. NEVER do your own arithmetic (no sums, differences, percentages, averages, rounding). Copy every number exactly as the tool returned it. If the user wants a calculation the tools don't return, run a query that returns it, or say it isn't available.

ANSWER FORMAT: plain text, at most 110 words. First sentence = the direct answer (or "I can't determine this from the data"). Then one or two sentences on why / which traps mattered. Mention units (₹ crore or USD). Don't name the tools.`;

  /** Number-grounding check: every number Claude writes must appear in a tool result (or the question). */
  A.ground = function (answer, toolOutputs, question) {
    const norm = s => s.replace(/,/g, "");
    const pool = new Set();
    const add = txt => { for (const m of norm(String(txt)).matchAll(/\d+(?:\.\d+)?/g)) { pool.add(m[0]); pool.add(String(Number(m[0]))); } };
    toolOutputs.forEach(t => add(JSON.stringify(t))); add(question || "");
    const found = [], ungrounded = [];
    for (const m of norm(answer).matchAll(/(?<![\w.])(\d+(?:\.\d+)?)(%?)/g)) {
      const v = m[1], n = Number(v);
      if (/^(19|20)\d\d$/.test(v) || (Number.isInteger(n) && n <= 31 && !m[2])) continue;   // years, days, quarter/step numbers
      found.push(v + m[2]);
      if (!pool.has(v) && !pool.has(String(n))) ungrounded.push(v + m[2]);
    }
    return { checked: found.length, ungrounded: [...new Set(ungrounded)] };
  };

  A.tools = function (d, hooks) {
    return [
      { name: "screen_question", description: "Deterministic first check of a question: catches invalid quarters (Q5), relative dates (last month), why/forecast questions, ambiguous fiscal years or quarters, and words not in the data. Returns verdict ok | hard_stop | unrecognised_words, with the reason. Call this first.",
        inputSchema: { type: "object", properties: { question: { type: "string", description: "The user's question, word for word (or the standalone form of a follow-up)." } }, required: ["question"] },
        execute: (input) => { const r = A.screen(input.question, d); hooks.onTool("screen_question", input, r); return r; } },
      { name: "query_ledger", description: "Runs one canonical question through the verified pipeline (exact decimal arithmetic, data-quality traps, truth gate, independent recount, Python proof). Returns status, answer or range, unit, method steps and traps. The ONLY source of numbers.",
        inputSchema: { type: "object", properties: { query: { type: "string", description: "One canonical question in the documented grammar, e.g. 'Net collection in Kerala in FY2025-26 Q4'." } }, required: ["query"] },
        execute: (input) => { const r = A.query(input.query, d); hooks.onTool("query_ledger", input, r.summary, r.full); return r.summary; } },
    ];
  };

  if (typeof module !== "undefined" && module.exports) module.exports = A; else root.A = A;
})(typeof window !== "undefined" ? window : globalThis);
