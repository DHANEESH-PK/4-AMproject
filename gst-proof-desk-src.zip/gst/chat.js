/* AI chat box for GST Proof Desk — Claude (sample capability) plans and explains,
   the verified engine (A.tools over G) computes, the page checks every number. */
(function () {
  "use strict";
  const $ = s => document.querySelector(s);
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const D = () => window.GPD_DATA;
  let sample = null, live = false, tier = "quick", ctl = null, busy = false;
  const history = [];
  const SUGG = ["How much IGST did Karnataka bring in during April 2026?", "Which zone pulled in the most GST in FY2026-27 Q1?", "Were May 2026 collections bigger than April's?", "What was collection last month?"];

  const box = $("#aichat"), fab = $("#aifab");
  function open(on) { box.hidden = !on; fab.setAttribute("aria-expanded", String(on)); if (on) setTimeout(() => $("#aiq").focus(), 50); }
  fab.addEventListener("click", () => open(box.hidden));
  $("#aiclose").addEventListener("click", () => open(false));
  $("#aisugg").innerHTML = SUGG.map(q => `<button type="button" class="chip" data-chatq="${esc(q)}"><span>${esc(q)}</span></button>`).join("");

  function setMode(isLive, why) {
    live = isLive;
    const m = $("#aimode"); m.className = "mode " + (isLive ? "live" : "off");
    m.querySelector("span").textContent = isLive ? "AI live" : "Rule engine";
    m.title = isLive ? "Claude reads and explains; the verified engine computes every number." : (why || "AI isn’t available in this view: questions go straight to the rule engine, without rewording.");
    $("#aitier").hidden = !isLive;
  }
  (async () => {
    try {
      const s = window.claude && await window.claude.use("sample");
      const lim = s && await s.limits().catch(() => null);
      if (s && lim && lim.tools) { sample = s; setMode(true); } else setMode(false);
    } catch (e) { setMode(false); }
  })();

  function stepHtml(name, input, out) {
    if (name === "screen_question") {
      const cls = out.verdict === "ok" ? "ok" : out.verdict === "hard_stop" ? "no" : "wa";
      return `<li><span class="ic ${cls}">1</span><span>Trap check: ${out.verdict === "ok" ? "clean" : out.verdict === "hard_stop" ? "<b>stopped</b>" : "unfamiliar words, so it was reworded"}</span></li>`;
    }
    const st = out.status, cls = st === "ANSWERED" ? "ok" : st.startsWith("ANSWERED") ? "wa" : "no";
    return `<li><span class="ic ${cls}">2</span><span>Ledger query <code>${esc(input.query)}</code> → ${esc(st.replace(/_/g, " ").toLowerCase())}</span></li>`;
  }
  function proofHtml(full) {
    const st = full.status, cls = st === "ANSWERED" ? "exact" : (st.startsWith("ANSWERED") || st === "CANNOT_DETERMINE_RANKING") ? "range" : "no";
    const unit = full.unit === "USD" ? "USD" : full.unit === "records" ? "records" : "₹ crore";
    let val = typeof full.answer === "string" ? `${full.answer} ${unit}` : Array.isArray(full.answer) && typeof full.answer[0] === "string" ? `${full.answer.join(" – ")} ${unit}` : full.verdict || "";
    return `<div class="pcard"><div class="row"><span class="pill ${cls}">${esc(st.replace(/_/g, " "))}</span><b>${esc(full.headline || "")}</b></div>${val ? `<div class="val">${esc(val)}</div>` : ""}
      <button type="button" class="btn" data-q="${esc(full.spec.question)}" style="margin-top:8px">Open full proof →</button></div>`;
  }
  function finish(card, text, summaries, fulls, q) {
    card.querySelector(".say").textContent = text;
    const g = A.ground(text, summaries, q);
    card.querySelector(".gwrap").innerHTML = g.ungrounded.length
      ? `<div class="ground no">⚠ Unverified number(s): <b>${esc(g.ungrounded.join(", "))}</b>. Not found in any proven result.</div>`
      : `<div class="ground ok">✓ ${g.checked ? `All ${g.checked} number(s) trace to proven results.` : "No figures stated."}</div>`;
    card.querySelector(".proofs").innerHTML = fulls.map(proofHtml).join("");
    card.scrollIntoView({ block: "nearest" });
  }
  function offline(q, card, hooks, summaries, fulls) {
    const s = A.screen(q, D()); hooks.onTool("screen_question", { question: q }, s);
    let text;
    if (s.verdict !== "ok") text = `I can’t determine this from the data. ${s.reason}${s.fix ? " " + s.fix : ""}` + (s.verdict === "unrecognised_words" ? "\n\n(Rule-engine mode can’t reword questions. Use the phrasing from the Ask tab.)" : "");
    else {
      const r = A.query(q, D()); hooks.onTool("query_ledger", { query: q }, r.summary, r.full); const o = r.summary;
      text = /CANNOT_DETERMINE$|INVALID/.test(o.status) ? `I can’t determine this from the data. ${o.reason}`
        : o.groups ? `${o.headline}. Open the full proof to see each group.` : o.verdict ? `${o.verdict}. ${o.headline}.`
        : `${o.headline}: ${Array.isArray(o.answer) ? "between " + o.answer.join(" and ") : o.answer} ${o.unit}.${o.status === "ANSWERED_RANGE" ? " Only a range is provable because some records can’t be placed with certainty." : ""}`;
    }
    finish(card, text, summaries, fulls, q);
  }
  async function ask(q) {
    q = q.trim(); if (!q || busy || !D()) return;
    busy = true; $("#aiq").value = ""; $("#aisugg").hidden = true;
    const log = $("#ailog");
    log.insertAdjacentHTML("beforeend", `<div class="you">${esc(q)}</div>`);
    const card = document.createElement("div"); card.className = "acard";
    card.innerHTML = `<ol class="steps2"></ol><div class="say"><span class="thinking"><i></i><i></i><i></i>&nbsp;${live ? "Thinking…" : "Working…"}</span></div><div class="gwrap"></div><div class="proofs"></div>`;
    log.append(card); card.scrollIntoView({ block: "nearest" });
    const summaries = [], fulls = [], steps = card.querySelector(".steps2");
    const hooks = { onTool: (name, input, out, full) => { summaries.push(out); if (full) fulls.push(full); steps.insertAdjacentHTML("beforeend", stepHtml(name, input, out)); } };
    $("#aisend").disabled = true; $("#aistop").hidden = !live;
    try {
      if (!live) return offline(q, card, hooks, summaries, fulls);
      ctl = new AbortController();
      const turns = [{ role: "user", content: A.RULES + "\n\n" + A.dataCard(D()) }, ...history.slice(-6), { role: "user", content: q }];
      try {
        const res = await sample(turns, { tools: A.tools(D(), hooks), modelTier: tier, signal: ctl.signal, onText: ({ text }) => { card.querySelector(".say").textContent = text; } });
        finish(card, res.text, summaries, fulls, q);
        history.push({ role: "user", content: q }, { role: "assistant", content: res.text });
      } catch (e) {
        const code = e && e.code;
        if (code === "cancelled") { card.querySelector(".say").textContent = (e.text || "") + "\n(Stopped.)"; return; }
        if (["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed", "tools_unavailable"].includes(code)) {
          setMode(false); steps.innerHTML = ""; summaries.length = 0; fulls.length = 0; return offline(q, card, hooks, summaries, fulls);
        }
        card.querySelector(".say").textContent = (e && e.text ? e.text + "\n\n" : "") + (code === "rate_limited" ? "Too many requests. Try again in a minute." : code === "refused" ? "Claude declined this one. Try rephrasing." : "The AI service had a hiccup. Ask again.");
      }
    } finally { busy = false; $("#aisend").disabled = false; $("#aistop").hidden = true; ctl = null; }
  }
  document.addEventListener("click", e => {
    const t = e.target.closest("button"); if (!t) return;
    if (t.dataset.chatq) ask(t.dataset.chatq);
    else if (t.dataset.aitier) { tier = t.dataset.aitier; document.querySelectorAll("#aitier button").forEach(b => b.setAttribute("aria-pressed", String(b === t))); }
    else if (t.id === "aistop") ctl?.abort();
    else if (t.dataset.q && t.closest("#aichat") && innerWidth < 700) open(false);   // full proof opens in the Ask tab
  });
  $("#aiform").addEventListener("submit", e => { e.preventDefault(); ask($("#aiq").value); });
})();
